// Loads the browser modules in the same order as index.html.
const Products = require('../js/products.js');
const Cart = require('../js/cart.js');
const Billing = require('../js/billing.js');
const Sensor = require('../js/sensor.js');
const Checkout = require('../js/checkout.js');
const Storage = require('../js/storage.js');

const { EVENT_TYPES } = Sensor;

// A small in-test session that drives the app the same way app.js does: every change is a sensor event.
function createSession(products) {
  const session = {
    products: products || Products.getSampleProducts(),
    cart: Cart.createCart(),
    sensor: Sensor.createSensorState(),
    send(eventType, productId, quantity, eventId) {
      const created = Sensor.createEvent(session.sensor, eventType, productId, quantity, { eventId });
      return session.apply(created.event, created.sensorState);
    },
    apply(event, sensorState) {
      const result = Sensor.processEvent(event, {
        products: session.products,
        cart: session.cart,
        sensorState: sensorState || session.sensor,
      });
      session.cart = result.cart;
      session.sensor = result.sensorState;
      return result;
    },
    add: (productId, quantity) => session.send(EVENT_TYPES.ADDED, productId, quantity),
    remove: (productId, quantity) => session.send(EVENT_TYPES.REMOVED, productId, quantity),
    qty: (productId) => Cart.getQuantity(session.cart, productId),
  };
  return session;
}

module.exports = { Products, Cart, Billing, Sensor, Checkout, Storage, createSession };
