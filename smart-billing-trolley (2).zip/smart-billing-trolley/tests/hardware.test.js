// Hardware layer: simulated sensor readings and the processing trace shown on the Hardware screen.
const test = require('node:test');
const assert = require('node:assert/strict');
const { Products, Cart, Billing, Sensor, createSession } = require('./helpers.js');
const Hardware = require('../js/hardware.js');

const catalog = Products.getSampleProducts();
const milk = Products.findProduct(catalog, 'P001');
const settings = Billing.getDefaultSettings();
const fixed = () => 0.5; // no load-cell noise

// Runs one detection the way hardware-view.js does: read sensors, forward to the validator, build the trace.
function detect(session, action, product, fault) {
  const cartBefore = session.cart;
  const reading = Hardware.readSensors({ action, product, cart: cartBefore, fault, random: fixed });
  let event = null;
  let result = null;
  if (reading.forward) {
    const created = Sensor.createEvent(session.sensor, reading.eventType, reading.tag, reading.quantity);
    event = created.event;
    result = session.apply(event, created.sensorState);
  }
  const trace = Hardware.buildTrace({ reading, event, result, cartBefore, settings, product });
  return { reading, event, result, trace };
}

const statusOf = (trace, kind) => trace.steps.filter((s) => s.kind === kind).map((s) => s.status);

test('sensor: processEvent reports the checks it ran, in order', () => {
  const s = createSession();
  const ok = s.add('P001');
  assert.deepEqual(ok.checks.map((c) => c.id), Sensor.CHECKS.map((c) => c.id));
  assert.ok(ok.checks.every((c) => c.ok));
  const unknown = s.add('P999');
  assert.deepEqual(unknown.checks.map((c) => [c.id, c.ok]), [['eventId', true], ['duplicate', true], ['type', true], ['product', false]]);
});

test('hardware: weights and cart weight', () => {
  assert.equal(Hardware.weightOf('P001'), 520);
  assert.equal(Hardware.weightOf('P404'), 500);
  const cart = Cart.addItem(Cart.addItem(Cart.createCart(), milk, 2).cart, Products.findProduct(catalog, 'P002')).cart;
  assert.equal(Hardware.cartWeight(cart), 520 * 2 + 400);
});

test('hardware: normal placement is accepted end to end', () => {
  const s = createSession();
  const { reading, event, result, trace } = detect(s, 'place', milk, 'none');
  assert.equal(reading.tag, milk.barcode, 'reader sends the barcode');
  assert.equal(reading.weightCheck, 'pass');
  assert.equal(event.productId, milk.barcode);
  assert.equal(result.status, 'ACCEPTED');
  assert.equal(trace.outcome, 'ACCEPTED');
  assert.deepEqual(trace.steps.map((st) => st.phase), [
    'sense', 'sense', 'sense', 'sense',
    'firmware', 'firmware', 'firmware', 'firmware', 'firmware', 'firmware',
    'output', 'output', 'output', 'output',
  ]);
  assert.ok(trace.steps.every((st) => st.status === 'pass'));
  assert.equal(trace.steps.find((st) => st.kind === 'cart').detail, 'Milk: 0 → 1');
  assert.ok(trace.totalMs > 0);
  const times = trace.steps.map((st) => st.atMs);
  assert.deepEqual(times, [...times].sort((a, b) => a - b), 'simulated time only moves forward');
  assert.equal(s.qty('P001'), 1);
});

test('hardware: weight mismatch discards the scan before the firmware', () => {
  const s = createSession();
  const { reading, result, trace } = detect(s, 'place', milk, 'notPlaced');
  assert.equal(reading.forward, false);
  assert.equal(result, null);
  assert.equal(trace.outcome, 'DISCARDED');
  assert.deepEqual(statusOf(trace, 'weigh'), ['fail']);
  assert.deepEqual(statusOf(trace, 'discard'), ['fail']);
  assert.equal(statusOf(trace, 'check').length, 0, 'validator never ran');
  assert.equal(s.cart.items.length, 0);
  assert.equal(s.sensor.log.length, 0, 'no sensor event was emitted');
});

test('hardware: taking out an item that is not in the trolley fails the weight check', () => {
  const s = createSession();
  const { reading, trace } = detect(s, 'remove', milk, 'none');
  assert.equal(reading.weightCheck, 'fail');
  assert.equal(trace.outcome, 'DISCARDED');
});

test('hardware: removal of a present item is accepted with a negative weight change', () => {
  const s = createSession();
  s.add('P001');
  const { reading, trace } = detect(s, 'remove', milk, 'none');
  assert.equal(reading.measuredDeltaG, -520);
  assert.equal(trace.outcome, 'ACCEPTED');
  assert.equal(s.qty('P001'), 0);
});

test('hardware: unknown code skips the weight check and is rejected by the product lookup', () => {
  const s = createSession();
  const { reading, trace } = detect(s, 'place', milk, 'unknownTag');
  assert.notEqual(reading.tag, milk.barcode);
  assert.equal(Products.findProduct(catalog, reading.tag), null);
  assert.deepEqual(statusOf(trace, 'weigh'), ['info']);
  assert.equal(trace.outcome, 'REJECTED');
  assert.deepEqual(statusOf(trace, 'check'), ['pass', 'pass', 'pass', 'fail', 'skip', 'skip']);
  assert.deepEqual(statusOf(trace, 'cart'), ['skip']);
  assert.deepEqual(statusOf(trace, 'buzzer'), ['fail']);
});

test('hardware: corrupted quantity is rejected by the quantity check', () => {
  const s = createSession();
  const { trace } = detect(s, 'place', milk, 'badQuantity');
  assert.equal(trace.outcome, 'REJECTED');
  assert.deepEqual(statusOf(trace, 'check'), ['pass', 'pass', 'pass', 'pass', 'fail', 'skip']);
});

test('hardware: out-of-stock product fails the stock rule', () => {
  const s = createSession();
  const cheese = Products.findProduct(catalog, 'P017');
  const { trace } = detect(s, 'place', cheese, 'none');
  assert.equal(trace.outcome, 'REJECTED');
  assert.deepEqual(statusOf(trace, 'check').slice(-1), ['fail']);
});

test('hardware: a retransmitted packet is ignored as a duplicate', () => {
  const s = createSession();
  const first = detect(s, 'place', milk, 'none');
  const cartBefore = s.cart;
  const result = s.apply({ ...first.event });
  const trace = Hardware.buildTrace({ reading: null, event: first.event, result, cartBefore, settings, product: milk, retransmit: true });
  assert.equal(trace.outcome, 'DUPLICATE');
  assert.equal(trace.steps[0].kind, 'retransmit');
  assert.deepEqual(statusOf(trace, 'check'), ['pass', 'fail', 'skip', 'skip', 'skip', 'skip']);
  assert.deepEqual(statusOf(trace, 'buzzer'), ['warn']);
  assert.equal(s.qty('P001'), 1, 'counted once');
});
