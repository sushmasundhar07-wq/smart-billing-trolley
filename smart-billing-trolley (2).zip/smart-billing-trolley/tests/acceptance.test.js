// Test cases TC01–TC12 from the project plan, in order.
const test = require('node:test');
const assert = require('node:assert/strict');
const { Billing, Checkout, Storage, Sensor, createSession } = require('./helpers.js');

const MILK = 'P001';
const BREAD = 'P002';

test('TC01 add milk once -> quantity 1', () => {
  const s = createSession();
  const result = s.add(MILK);
  assert.equal(result.status, 'ACCEPTED');
  assert.equal(s.qty(MILK), 1);
});

test('TC02 add milk twice -> quantity 2', () => {
  const s = createSession();
  s.add(MILK);
  s.add(MILK);
  assert.equal(s.qty(MILK), 2);
  assert.equal(s.cart.items.length, 1, 'still a single cart line');
});

test('TC03 remove one milk from quantity 2 -> quantity 1', () => {
  const s = createSession();
  s.add(MILK);
  s.add(MILK);
  assert.equal(s.remove(MILK).status, 'ACCEPTED');
  assert.equal(s.qty(MILK), 1);
});

test('TC04 remove final milk -> milk disappears from cart', () => {
  const s = createSession();
  s.add(MILK);
  s.remove(MILK);
  assert.equal(s.cart.items.find((item) => item.productId === MILK), undefined);
  assert.equal(s.cart.items.length, 0);
});

test('TC05 remove milk when absent -> error message, cart unchanged', () => {
  const s = createSession();
  s.add(BREAD);
  const before = s.cart;
  const result = s.remove(MILK);
  assert.equal(result.status, 'REJECTED');
  assert.match(result.message, /not in the trolley/);
  assert.equal(s.cart, before, 'same cart object returned');
  assert.deepEqual(s.cart.items.map((i) => [i.productId, i.quantity]), [[BREAD, 1]]);
});

test('TC06 unknown product ID -> event rejected', () => {
  const s = createSession();
  const result = s.add('P999');
  assert.equal(result.status, 'REJECTED');
  assert.match(result.message, /unknown product ID "P999"/);
  assert.equal(s.cart.items.length, 0);
});

test('TC07 duplicate event ID -> processed only once', () => {
  const s = createSession();
  const first = s.send('ITEM_ADDED', MILK, 1, 'EVT-0100');
  const second = s.send('ITEM_ADDED', MILK, 1, 'EVT-0100');
  assert.equal(first.status, 'ACCEPTED');
  assert.equal(second.status, 'DUPLICATE');
  assert.equal(s.qty(MILK), 1);
  assert.equal(s.sensor.log.length, 2, 'duplicate is still logged');
});

test('TC08 refresh browser -> active cart restored', () => {
  const backend = Storage.createMemoryBackend();
  const s = createSession();
  s.add(MILK);
  s.add(MILK);
  s.add(BREAD);
  const first = Storage.createStorage(backend);
  first.saveCart(s.cart);
  first.saveSensorState(s.sensor);

  const reloaded = Storage.createStorage(backend); // simulates a new page load
  assert.deepEqual(reloaded.loadCart(), s.cart);
  assert.equal(reloaded.loadSensorState().sequence, 3, 'event numbering continues after reload');
});

test('TC09 checkout empty cart -> checkout blocked', () => {
  const s = createSession();
  const result = Checkout.completeCheckout({ cart: s.cart, products: s.products, settings: {}, transactions: [] });
  assert.equal(result.ok, false);
  assert.match(result.errors[0], /trolley is empty/);
});

test('TC10 complete checkout -> receipt created and cart cleared', () => {
  const s = createSession();
  s.add(MILK);
  s.add(BREAD);
  const result = Checkout.completeCheckout({
    cart: s.cart,
    products: s.products,
    settings: { defaultTaxPercent: 0, categoryTaxPercent: {}, discount: { type: 'none', value: 0 } },
    transactions: [],
    now: new Date(2026, 9, 24, 12, 0, 0),
  });
  assert.equal(result.ok, true);
  assert.match(result.transaction.transactionId, /^TXN-20261024-120000-[0-9A-Z]{4}$/);
  assert.equal(result.transaction.grandTotalPaise, 7000);
  assert.equal(result.cart.items.length, 0);
  assert.equal(result.transactions.length, 1);
  const receipt = Checkout.receiptText(result.transaction);
  assert.match(receipt, /Milk/);
  assert.match(receipt, /Bread/);
  assert.match(receipt, /TOTAL\s+₹70\.00/);
});

test('TC11 refresh after checkout -> completed transaction remains available', () => {
  const backend = Storage.createMemoryBackend();
  const s = createSession();
  s.add(MILK);
  const result = Checkout.completeCheckout({ cart: s.cart, products: s.products, settings: {}, transactions: [] });
  const first = Storage.createStorage(backend);
  first.saveTransactions(result.transactions);
  first.saveCart(result.cart);

  const reloaded = Storage.createStorage(backend);
  const history = reloaded.loadTransactions();
  assert.equal(history.length, 1);
  assert.equal(history[0].transactionId, result.transaction.transactionId);
  assert.equal(reloaded.loadCart().items.length, 0);
});

test('TC12 apply tax and discount -> correct total', () => {
  const s = createSession();
  s.add(MILK, 2); // Dairy ₹30 × 2 = ₹60.00
  s.add('P016'); // Household ₹99.00
  const settings = {
    defaultTaxPercent: 5,
    categoryTaxPercent: { Household: 18 },
    discount: { type: 'percent', value: 10 },
  };
  const bill = Billing.calculateBill(s.cart.items, settings);
  assert.equal(bill.subtotalPaise, 15900);
  assert.equal(bill.taxPaise, 300 + 1782); // 5% of 60.00 + 18% of 99.00
  assert.equal(bill.discountPaise, 1590); // 10% of subtotal
  assert.equal(bill.grandTotalPaise, 15900 + 2082 - 1590);
  assert.equal(Billing.formatPaise(bill.grandTotalPaise), '₹163.92');
});

test('end-to-end example from the plan', () => {
  const s = createSession();
  s.add(MILK);
  s.add(BREAD);
  s.remove(MILK);
  assert.deepEqual(s.cart.items.map((item) => item.productId), [BREAD]);
  const result = Checkout.completeCheckout({ cart: s.cart, products: s.products, settings: {}, transactions: [] });
  assert.equal(result.ok, true);
  assert.equal(result.transaction.items.length, 1);
  assert.equal(result.cart.items.length, 0);
  assert.deepEqual(s.sensor.log.map((r) => r.status), ['ACCEPTED', 'ACCEPTED', 'ACCEPTED']);
  assert.deepEqual(s.sensor.log.map((r) => r.eventId), ['EVT-0003', 'EVT-0002', 'EVT-0001'], 'newest first');
  assert.equal(Sensor.formatEventId(12), 'EVT-0012');
});
