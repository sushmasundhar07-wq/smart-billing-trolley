// Module-level unit tests and edge cases beyond the acceptance list.
const test = require('node:test');
const assert = require('node:assert/strict');
const { Products, Cart, Billing, Sensor, Checkout, Storage, createSession } = require('./helpers.js');

const catalog = Products.getSampleProducts();
const milk = Products.findProduct(catalog, 'P001');

test('products: lookup by ID (any case) and barcode', () => {
  assert.equal(Products.findProduct(catalog, 'p001').name, 'Milk');
  assert.equal(Products.findProduct(catalog, ' 2000000000002 ').name, 'Bread');
  assert.equal(Products.findProduct(catalog, ''), null);
  assert.equal(Products.findProduct(catalog, undefined), null);
});

test('products: search by name/code and filter by category', () => {
  assert.deepEqual(Products.searchProducts(catalog, 'mil', 'All').map((p) => p.id), ['P001']);
  assert.ok(Products.searchProducts(catalog, '', 'Fruits').every((p) => p.category === 'Fruits'));
  assert.equal(Products.searchProducts(catalog, 'milk', 'Fruits').length, 0);
  assert.equal(Products.searchProducts(catalog, '2000000000013', 'All')[0].name, 'Biscuits');
  assert.ok(Products.getCategories(catalog).includes('Dairy'));
});

test('products: sample catalog is valid and copies are independent', () => {
  assert.ok(Products.isValidCatalog(catalog));
  const copy = Products.getSampleProducts();
  copy[0].stock = 0;
  assert.equal(Products.getSampleProducts()[0].stock, 40);
});

test('cart: operations never mutate the input cart', () => {
  const empty = Cart.createCart();
  const one = Cart.addItem(empty, milk).cart;
  assert.equal(empty.items.length, 0);
  const two = Cart.addItem(one, milk).cart;
  assert.equal(one.items[0].quantity, 1);
  assert.equal(two.items[0].quantity, 2);
});

test('cart: rejects invalid quantities', () => {
  for (const bad of [0, -1, 1.5, '2', NaN, null]) {
    assert.equal(Cart.addItem(Cart.createCart(), milk, bad).ok, false, `add ${bad}`);
  }
  const cart = Cart.addItem(Cart.createCart(), milk, 2).cart;
  assert.equal(Cart.removeItem(cart, milk, 3).ok, false, 'cannot remove more than present');
  assert.equal(Cart.removeItem(cart, milk, -1).ok, false);
});

test('cart: stock limit prevents over-adding', () => {
  const chips = Products.findProduct(catalog, 'P014'); // stock 4
  const full = Cart.addItem(Cart.createCart(), chips, 4);
  assert.equal(full.ok, true);
  const over = Cart.addItem(full.cart, chips, 1);
  assert.equal(over.ok, false);
  assert.match(over.message, /out of stock/);
  const cheese = Products.findProduct(catalog, 'P017'); // stock 0
  assert.equal(Cart.addItem(Cart.createCart(), cheese).ok, false);
});

test('cart: totals and validation', () => {
  let cart = Cart.addItem(Cart.createCart(), milk, 3).cart;
  cart = Cart.addItem(cart, Products.findProduct(catalog, 'P002')).cart;
  assert.equal(Cart.totalUnits(cart), 4);
  assert.equal(Cart.uniqueProducts(cart), 2);
  assert.ok(Cart.isValidCart(cart));
  assert.equal(Cart.isValidCart({ items: [{ productId: 'P001', name: 'x', category: 'y', unitPricePaise: 100, quantity: -1 }] }), false);
  assert.equal(Cart.isValidCart(null), false);
});

test('sensor: rejects unsupported types, bad quantity and missing ID', () => {
  const s = createSession();
  assert.equal(s.send('ITEM_SCANNED', 'P001', 1).status, 'REJECTED');
  assert.equal(s.send('ITEM_ADDED', 'P001', 0).status, 'REJECTED');
  assert.equal(s.send('ITEM_ADDED', 'P001', 1.5).status, 'REJECTED');
  assert.equal(s.send('ITEM_ADDED', 'P001', NaN).status, 'REJECTED');
  const missing = s.apply({ productId: 'P001', eventType: 'ITEM_ADDED', quantity: 1 });
  assert.equal(missing.status, 'REJECTED');
  assert.match(missing.message, /missing event ID/);
  assert.equal(s.apply(null).status, 'REJECTED');
  assert.equal(s.cart.items.length, 0, 'no rejected event touched the cart');
});

test('sensor: accepts barcode as product identifier', () => {
  const s = createSession();
  assert.equal(s.add('2000000000001').status, 'ACCEPTED');
  assert.equal(s.qty('P001'), 1);
});

test('sensor: rejected event IDs are also deduplicated', () => {
  const s = createSession();
  assert.equal(s.send('ITEM_REMOVED', 'P001', 1, 'EVT-X').status, 'REJECTED');
  assert.equal(s.send('ITEM_REMOVED', 'P001', 1, 'EVT-X').status, 'DUPLICATE');
});

test('sensor: auto IDs skip IDs that were already used manually', () => {
  const s = createSession();
  s.send('ITEM_ADDED', 'P001', 1, 'EVT-0001');
  const result = s.add('P001');
  assert.equal(result.record.eventId, 'EVT-0002');
  assert.equal(result.status, 'ACCEPTED');
});

test('sensor: log and tracked IDs are bounded', () => {
  const s = createSession();
  for (let i = 0; i < 1100; i += 1) s.send('ITEM_ADDED', 'P999', 1);
  assert.equal(s.sensor.log.length, 200);
  assert.equal(s.sensor.processedIds.length, 1000);
});

test('billing: subtotal, per-line tax rounding, and empty bill', () => {
  const items = [{ productId: 'X', name: 'X', category: 'Misc', unitPricePaise: 3333, quantity: 3 }];
  const bill = Billing.calculateBill(items, { defaultTaxPercent: 5, categoryTaxPercent: {}, discount: { type: 'none', value: 0 } });
  assert.equal(bill.subtotalPaise, 9999);
  assert.equal(bill.taxPaise, 500); // 499.95 rounds half-up to 500
  assert.equal(bill.grandTotalPaise, 10499);
  const empty = Billing.calculateBill([], {});
  assert.deepEqual([empty.subtotalPaise, empty.taxPaise, empty.discountPaise, empty.grandTotalPaise], [0, 0, 0, 0]);
});

test('billing: category tax override including zero-rated categories', () => {
  const items = [
    { productId: 'A', name: 'A', category: 'Fruits', unitPricePaise: 10000, quantity: 1 },
    { productId: 'B', name: 'B', category: 'Dairy', unitPricePaise: 10000, quantity: 1 },
  ];
  const bill = Billing.calculateBill(items, { defaultTaxPercent: 5, categoryTaxPercent: { Fruits: 0 } });
  assert.deepEqual(bill.lines.map((l) => l.taxPaise), [0, 500]);
});

test('billing: flat discount is capped at the subtotal', () => {
  const items = [{ productId: 'A', name: 'A', category: 'Misc', unitPricePaise: 1000, quantity: 1 }];
  const bill = Billing.calculateBill(items, { defaultTaxPercent: 0, categoryTaxPercent: {}, discount: { type: 'flat', value: 5000 } });
  assert.equal(bill.discountPaise, 1000);
  assert.equal(bill.grandTotalPaise, 0);
});

test('billing: invalid settings fall back to defaults', () => {
  const s = Billing.normaliseSettings({ defaultTaxPercent: -4, categoryTaxPercent: { Dairy: 150, Snacks: 12 }, discount: { type: 'percent', value: 'x' } });
  assert.equal(s.defaultTaxPercent, 5);
  assert.deepEqual(s.categoryTaxPercent, { Snacks: 12 });
  assert.deepEqual(s.discount, { type: 'none', value: 0 });
  assert.deepEqual(Billing.normaliseSettings(null), Billing.getDefaultSettings());
});

test('billing: currency formatting and parsing', () => {
  assert.equal(Billing.formatPaise(0), '₹0.00');
  assert.equal(Billing.formatPaise(3000), '₹30.00');
  assert.equal(Billing.formatPaise(5), '₹0.05');
  assert.equal(Billing.formatPaise(12345670), '₹1,23,456.70');
  assert.equal(Billing.formatPaise(-1050), '-₹10.50');
  assert.equal(Billing.rupeesToPaise('30'), 3000);
  assert.equal(Billing.rupeesToPaise('1.005'), null);
  assert.equal(Billing.rupeesToPaise('0.1'), 10);
  assert.equal(Billing.rupeesToPaise('19.99'), 1999);
  assert.equal(Billing.rupeesToPaise('-5'), null);
  assert.equal(Billing.rupeesToPaise('abc'), null);
});

test('checkout: transaction snapshot preserves prices after catalog changes', () => {
  const s = createSession();
  s.add('P001', 2);
  const result = Checkout.completeCheckout({ cart: s.cart, products: s.products, settings: {}, transactions: [] });
  s.products[0].pricePaise = 99999;
  assert.equal(result.transaction.items[0].unitPricePaise, 3000);
});

test('checkout: stock is deducted without mutating the input catalog', () => {
  const s = createSession();
  s.add('P001', 3);
  const result = Checkout.completeCheckout({ cart: s.cart, products: s.products, settings: {}, transactions: [] });
  assert.equal(Products.findProduct(result.products, 'P001').stock, 37);
  assert.equal(Products.findProduct(s.products, 'P001').stock, 40);
});

test('checkout: blocked when cart exceeds current stock', () => {
  const s = createSession();
  s.add('P001', 5);
  const lowStock = s.products.map((p) => (p.id === 'P001' ? { ...p, stock: 2 } : p));
  const result = Checkout.completeCheckout({ cart: s.cart, products: lowStock, settings: {}, transactions: [] });
  assert.equal(result.ok, false);
  assert.match(result.errors[0], /Only 2 Milk in stock/);
});

test('checkout: transaction IDs are unique even on suffix collision', () => {
  const now = new Date(2026, 9, 24, 9, 5, 7);
  const values = [0, 0, 0.5];
  const random = () => values.shift();
  const first = Checkout.generateTransactionId(now, [], () => 0);
  const second = Checkout.generateTransactionId(now, [first], random);
  assert.equal(first, 'TXN-20261024-090507-0000');
  assert.notEqual(second, first);
  assert.throws(() => Checkout.generateTransactionId(now, [first], () => 0));
});

test('storage: corrupt or invalid data falls back to defaults', () => {
  const backend = Storage.createMemoryBackend();
  backend.setItem(Storage.KEYS.cart, '{not json');
  backend.setItem(Storage.KEYS.products, JSON.stringify([{ id: 'bad' }]));
  backend.setItem(Storage.KEYS.transactions, JSON.stringify({ nope: true }));
  backend.setItem(Storage.KEYS.events, JSON.stringify({ sequence: -1 }));
  const store = Storage.createStorage(backend);
  assert.deepEqual(store.loadCart(), { items: [] });
  assert.equal(store.loadProducts().length, Products.getSampleProducts().length);
  assert.deepEqual(store.loadTransactions(), []);
  assert.deepEqual(store.loadSensorState(), Sensor.createSensorState());
  assert.deepEqual(store.loadSettings(), Billing.getDefaultSettings());
});

test('storage: products are seeded once and saved settings round-trip', () => {
  const backend = Storage.createMemoryBackend();
  const store = Storage.createStorage(backend);
  assert.equal(backend.getItem(Storage.KEYS.products), null);
  store.loadProducts();
  assert.notEqual(backend.getItem(Storage.KEYS.products), null);
  const settings = { defaultTaxPercent: 12, categoryTaxPercent: { Dairy: 0 }, discount: { type: 'flat', value: 2500 } };
  store.saveSettings(settings);
  assert.deepEqual(Storage.createStorage(backend).loadSettings(), settings);
  store.clearAll();
  assert.equal(backend.getItem(Storage.KEYS.settings), null);
});

test('storage: write failures are reported instead of thrown', () => {
  const failing = { getItem: () => null, setItem: () => { throw new Error('QuotaExceeded'); }, removeItem() {} };
  const store = Storage.createStorage(failing);
  assert.equal(store.saveCart({ items: [] }), false);
});
