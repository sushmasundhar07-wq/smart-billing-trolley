# Smart Billing Trolley — Software-Only Simulation

A web application that simulates a smart supermarket trolley. Products "entering" and "leaving" the trolley are simulated sensor events. Each event is validated, the cart is updated, the bill is recalculated, and checkout produces an itemised receipt that is saved to history.

> **Scope note:** No physical sensors, barcode scanners, RFID readers or payment systems are involved. On-screen controls generate every sensor event, and payments are simulated.

## Running it

No build step or dependencies.

- **Open directly:** double-click `index.html`. It works over `file://` in Chrome, Edge and Firefox.
- **Or serve it:** `npx serve .` or `python -m http.server`, then open the printed URL.
- **Run the tests (Node 18+):** `npm test`

## Features

| Module | What it does |
| --- | --- |
| Product catalog | 17 sample products with ID, barcode, category, price and stock. Search by name, ID or barcode, filter by category, and see live availability. |
| Simulated sensor | `ITEM_ADDED` / `ITEM_REMOVED` events with sequential IDs (`EVT-0001`…). Validates event type, product, quantity and duplicate IDs. The sensor simulator panel can inject raw events, and an event log is kept. |
| Trolley management | Add, remove one unit, or remove an item entirely. Stock limits are enforced, and quantities can never go negative. The cart is saved and restored on reload. |
| Billing engine | Line totals, per-category tax rates, percentage or flat discounts, and an automatic grand total. All money is stored as integer paise. |
| LCD dashboard | A 20×4 character LCD shows the last event, status (ADDED / REMOVED / REJECTED / DUPLICATE / PAID), units, items and the running total. |
| Checkout & history | Cart validation, unique transaction IDs (`TXN-YYYYMMDD-HHMMSS-XXXX`), price snapshot, stock deduction, printable receipt, `.txt` download, and persistent transaction history. |

### Hardware screen

The **Hardware** tab shows how one item is processed inside a smart trolley, step by step:

1. **Sense:** the IR gate sees the item cross the basket rim, the code reader reads its barcode, the load cell checks the weight change, and the microcontroller builds the event packet (shown as JSON).
2. **Validate:** the firmware runs the same checks as the rest of the app: event ID, duplicate, event type, product lookup, quantity, and stock or trolley rule.
3. **Respond:** the trolley and bill are updated, the LCD refreshes, and the buzzer and LED confirm or warn.

A labelled trolley drawing highlights each part as it works. A serial monitor prints firmware-style log lines with simulated timings. You can slow the animation down, skip it, or inject a fault: an unknown code, an item scanned but not placed (weight mismatch), a corrupted quantity, or a sensor double-fire (duplicate packet). Every action on this screen goes through the real event pipeline, so it updates the same trolley as the Shop tab. All readings, weights and timings are simulated.

**Simulating a barcode scan:** type an exact product ID (`P004`) or barcode (`2000000000004`) in the search box and press **Enter**.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│ 1. User interface   index.html, css/style.css, js/app.js    │
├─────────────────────────────────────────────────────────────┤
│ 2. Event simulation js/sensor.js  (+ lookup in products.js) │
├─────────────────────────────────────────────────────────────┤
│ 3. Application logic js/cart.js, js/billing.js,             │
│                      js/checkout.js                         │
├─────────────────────────────────────────────────────────────┤
│ 4. Persistence       js/storage.js → localStorage           │
└─────────────────────────────────────────────────────────────┘
```

Design rules the code follows:

- **The cart is the source of truth.** Totals, the LCD and badges are always recalculated from the cart contents. Nothing stores a running total.
- **Buttons never edit the cart directly.** Every Add/Remove button emits a sensor event and goes through the same validation pipeline as raw events from the simulator.
- **Logic modules are pure.** `cart`, `billing`, `sensor` and `checkout` take state in and return new state without mutating their inputs and without touching the DOM. That is why they can be unit-tested in Node.
- **Money is integer paise.** Percentages are converted to basis points, and each tax or discount amount is rounded once (half-up), so there is no floating-point drift.

### Files

| File | Responsibility |
| --- | --- |
| `index.html` | Page structure; loads scripts in dependency order |
| `css/style.css` | Responsive layout, LCD styling, receipt and print styles, dark mode |
| `js/products.js` | Sample catalog, lookup by ID/barcode, search, categories |
| `js/cart.js` | Add/remove operations, totals, cart validation |
| `js/billing.js` | Subtotal, tax, discount, grand total, currency formatting |
| `js/sensor.js` | Event creation, validation and processing, duplicate protection, event log |
| `js/checkout.js` | Checkout validation, transaction IDs and snapshots, text receipts |
| `js/storage.js` | Validated load/save for all demo data |
| `js/hardware.js` | Simulated sensor readings (IR, reader, load cell) and the step-by-step processing trace |
| `js/app.js` | Rendering, UI event handlers, wiring between modules |
| `js/hardware-view.js` | Hardware screen: trolley drawing, pipeline animation, serial monitor |
| `tests/` | `node:test` suites: acceptance cases TC01–TC12, unit/edge cases, hardware simulation |

### Event format

```js
{
  eventId: "EVT-0001",
  productId: "P001",         // product ID or barcode
  eventType: "ITEM_ADDED",   // or "ITEM_REMOVED"
  quantity: 1,               // positive whole number
  timestamp: "2026-10-24T06:30:00.000Z"
}
```

The processor checks, in order: event ID present → not a duplicate → supported type → known product → valid quantity → cart rule (stock available / item present). If any check fails, the cart is left unchanged and the event is logged as `REJECTED` or `DUPLICATE`.

### Billing formula

```
Line total  = unit price × quantity
Line tax    = round(line total × category tax rate)
Subtotal    = Σ line totals
Discount    = round(subtotal × %)  or  flat amount, capped at subtotal
Grand total = subtotal + Σ line tax − discount
```

Default demo tax rates are 5% for most categories, 0% for Fruits and Vegetables, 12% for Snacks and 18% for Household. You can edit all of them on the Checkout page. **They are for demonstration only and must not be read as official tax rates.**

### Storage keys

`smartTrolley.products`, `smartTrolley.cart`, `smartTrolley.events`, `smartTrolley.transactions`, `smartTrolley.settings`.

Corrupt or invalid stored data is ignored and replaced with defaults. If `localStorage` is blocked, the app still runs from memory and shows a warning. Use **Reset demo data** in the footer to start fresh.

## Test cases

Run with `npm test`. The suite has 47 tests: the 13 acceptance tests below, 24 unit/edge-case tests, and 10 hardware-simulation tests.

| ID | Scenario | Expected | Status |
| --- | --- | --- | --- |
| TC01 | Add milk once | Quantity = 1 | Pass |
| TC02 | Add milk twice | Quantity = 2 | Pass |
| TC03 | Remove one milk from quantity 2 | Quantity = 1 | Pass |
| TC04 | Remove final milk | Milk disappears from cart | Pass |
| TC05 | Remove milk when absent | Error message; cart unchanged | Pass |
| TC06 | Unknown product ID | Event rejected | Pass |
| TC07 | Duplicate event ID | Processed only once | Pass |
| TC08 | Refresh browser | Active cart restored | Pass |
| TC09 | Checkout empty cart | Checkout blocked | Pass |
| TC10 | Complete checkout | Receipt created, cart cleared | Pass |
| TC11 | Refresh after checkout | Transaction still available | Pass |
| TC12 | Apply tax and discount | Correct total (₹163.92 worked example) | Pass |

Extra unit tests cover stock limits, invalid quantities (0, negative, decimal, string, NaN), barcode lookup, rounding, flat-discount capping, settings validation, ₹ formatting with Indian digit grouping, price snapshots, transaction-ID collisions, corrupt storage, and storage write failures.

### Manual demo script

1. Add Milk twice and Bread once. The LCD shows `ADDED`, and the trolley and total update.
2. Press **−** on Milk. The LCD turns amber and shows `REMOVED`.
3. In the sensor simulator, send `P999`. The event is `REJECTED` and the LCD turns red.
4. Send `P001` with event ID `EVT-TEST` twice. The second is `DUPLICATE` and the quantity does not change.
5. Reload the page. The trolley is restored.
6. Open Checkout, set a 10% discount, and confirm. A receipt appears and the trolley clears.
7. Open History and reload. The transaction is still there. Print it or download it.

## Limitations

- `localStorage` is per-browser and per-device. It is not secure, transactional or multi-user, so it is suitable for a demonstration only.
- Product detection is simulated and there is no hardware integration.
- Payment is simulated.

## Future enhancements

Barcode scanner input, RFID or camera-based detection, a backend database with multi-user sessions, an admin dashboard for inventory and pricing, a simulated payment gateway, and purchase analytics.
