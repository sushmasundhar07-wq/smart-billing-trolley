/* Persistence for demo data. Every read is validated, so corrupt or missing data falls back to defaults. */
(function (global) {
  'use strict';

  const ns = global.SmartTrolley || (global.SmartTrolley = {});
  const Products = ns.Products || require('./products.js');
  const Cart = ns.Cart || require('./cart.js');
  const Billing = ns.Billing || require('./billing.js');
  const Sensor = ns.Sensor || require('./sensor.js');
  const Checkout = ns.Checkout || require('./checkout.js');

  const KEYS = Object.freeze({
    products: 'smartTrolley.products',
    cart: 'smartTrolley.cart',
    events: 'smartTrolley.events',
    transactions: 'smartTrolley.transactions',
    settings: 'smartTrolley.settings',
  });

  function createMemoryBackend() {
    const map = new Map();
    return {
      getItem: (key) => (map.has(key) ? map.get(key) : null),
      setItem: (key, value) => { map.set(key, String(value)); },
      removeItem: (key) => { map.delete(key); },
    };
  }

  // localStorage can be missing or throw (private mode, blocked site data); fall back to memory.
  function browserBackend() {
    try {
      const probe = 'smartTrolley.__probe';
      global.localStorage.setItem(probe, '1');
      global.localStorage.removeItem(probe);
      return global.localStorage;
    } catch (error) {
      return null;
    }
  }

  function createStorage(backend) {
    const store = backend || browserBackend();
    const persistent = !!store;
    const target = store || createMemoryBackend();

    function read(key, isValid) {
      try {
        const raw = target.getItem(key);
        if (raw === null || raw === undefined) return null;
        const value = JSON.parse(raw);
        return isValid(value) ? value : null;
      } catch (error) {
        return null;
      }
    }

    function write(key, value) {
      try {
        target.setItem(key, JSON.stringify(value));
        return true;
      } catch (error) {
        return false;
      }
    }

    return {
      isPersistent: persistent,

      loadProducts() {
        const saved = read(KEYS.products, Products.isValidCatalog);
        if (saved) return saved;
        const seeded = Products.getSampleProducts();
        write(KEYS.products, seeded);
        return seeded;
      },
      saveProducts: (products) => write(KEYS.products, products),

      loadCart: () => read(KEYS.cart, Cart.isValidCart) || Cart.createCart(),
      saveCart: (cart) => write(KEYS.cart, cart),

      loadSensorState: () => read(KEYS.events, Sensor.isValidSensorState) || Sensor.createSensorState(),
      saveSensorState: (sensorState) => write(KEYS.events, sensorState),

      loadTransactions: () => read(KEYS.transactions, Checkout.isValidTransactionList) || [],
      saveTransactions: (transactions) => write(KEYS.transactions, transactions),

      loadSettings: () => Billing.normaliseSettings(read(KEYS.settings, (value) => !!value && typeof value === 'object')),
      saveSettings: (settings) => write(KEYS.settings, settings),

      clearAll() {
        Object.values(KEYS).forEach((key) => {
          try { target.removeItem(key); } catch (error) { /* nothing to clear */ }
        });
      },
    };
  }

  const Storage = { KEYS, createMemoryBackend, createStorage };

  ns.Storage = Storage;
  if (typeof module === 'object' && module.exports) module.exports = Storage;
})(typeof globalThis !== 'undefined' ? globalThis : this);
