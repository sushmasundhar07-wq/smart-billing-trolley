/*
 * Simulated trolley sensor. UI controls never touch the cart directly: they emit an event, and the
 * event processor validates it and applies it to the cart. Product detection is simulated in software.
 */
(function (global) {
  'use strict';

  const ns = global.SmartTrolley || (global.SmartTrolley = {});
  const Products = ns.Products || require('./products.js');
  const Cart = ns.Cart || require('./cart.js');

  const EVENT_TYPES = Object.freeze({ ADDED: 'ITEM_ADDED', REMOVED: 'ITEM_REMOVED' });
  const EVENT_STATUS = Object.freeze({ ACCEPTED: 'ACCEPTED', REJECTED: 'REJECTED', DUPLICATE: 'DUPLICATE' });

  // Bounded so localStorage cannot grow without limit; IDs older than this window are no longer deduplicated.
  const MAX_LOG_ENTRIES = 200;
  const MAX_TRACKED_IDS = 1000;

  function createSensorState() {
    return { sequence: 0, processedIds: [], log: [] };
  }

  function isValidSensorState(state) {
    return !!state &&
      Number.isInteger(state.sequence) && state.sequence >= 0 &&
      Array.isArray(state.processedIds) && state.processedIds.every((id) => typeof id === 'string') &&
      Array.isArray(state.log);
  }

  function formatEventId(sequence) {
    return `EVT-${String(sequence).padStart(4, '0')}`;
  }

  /*
   * Builds an event. Without options.eventId the next sequential ID is used, skipping any ID already
   * seen (for example one typed manually into the simulator), and the returned sensorState advances.
   */
  function createEvent(sensorState, eventType, productId, quantity, options) {
    const opts = options || {};
    let sequence = sensorState.sequence;
    let eventId = opts.eventId;
    if (!eventId) {
      do {
        sequence += 1;
        eventId = formatEventId(sequence);
      } while (sensorState.processedIds.includes(eventId));
    }
    return {
      event: {
        eventId,
        productId,
        eventType,
        quantity: quantity === undefined ? 1 : quantity,
        timestamp: (opts.now || new Date()).toISOString(),
      },
      sensorState: { ...sensorState, sequence },
    };
  }

  // Validation checks in the order processEvent runs them; the hardware screen shows unrun ones as skipped.
  const CHECKS = Object.freeze([
    { id: 'eventId', label: 'Event ID present' },
    { id: 'duplicate', label: 'Not a duplicate event' },
    { id: 'type', label: 'Supported event type' },
    { id: 'product', label: 'Product found in catalog' },
    { id: 'quantity', label: 'Valid quantity' },
    { id: 'cartRule', label: 'Stock / trolley rule' },
  ]);

  /*
   * Validates an event and applies it. Returns { status, message, product, record, checks, cart, sensorState }.
   * On anything but ACCEPTED the returned cart is the unchanged input cart.
   */
  function processEvent(event, context) {
    const { products, cart, sensorState } = context;
    const input = event && typeof event === 'object' ? event : {};
    const eventId = typeof input.eventId === 'string' ? input.eventId.trim() : '';
    const checks = [];

    function check(id, ok, detail, label) {
      checks.push({ id, label: label || CHECKS.find((c) => c.id === id).label, ok, detail });
      return ok;
    }

    function finish(status, message, product, nextCart) {
      const record = {
        eventId: eventId || '(none)',
        productId: input.productId === undefined || input.productId === null ? '' : String(input.productId),
        eventType: input.eventType === undefined ? '' : String(input.eventType),
        quantity: input.quantity,
        timestamp: typeof input.timestamp === 'string' ? input.timestamp : new Date().toISOString(),
        status,
        message,
        productName: product ? product.name : null,
      };
      const trackId = eventId && status !== EVENT_STATUS.DUPLICATE;
      return {
        status,
        message,
        product: product || null,
        record,
        checks,
        cart: nextCart || cart,
        sensorState: {
          ...sensorState,
          processedIds: trackId ? sensorState.processedIds.concat(eventId).slice(-MAX_TRACKED_IDS) : sensorState.processedIds,
          log: [record].concat(sensorState.log).slice(0, MAX_LOG_ENTRIES),
        },
      };
    }

    if (!check('eventId', !!eventId, eventId || 'Missing')) {
      return finish(EVENT_STATUS.REJECTED, 'Event rejected: missing event ID.');
    }
    if (!check('duplicate', !sensorState.processedIds.includes(eventId),
      sensorState.processedIds.includes(eventId) ? `${eventId} was already processed` : `${eventId} is new`)) {
      return finish(EVENT_STATUS.DUPLICATE, `Duplicate event ${eventId} ignored.`);
    }
    const supported = input.eventType === EVENT_TYPES.ADDED || input.eventType === EVENT_TYPES.REMOVED;
    if (!check('type', supported, String(input.eventType))) {
      return finish(EVENT_STATUS.REJECTED, `Event rejected: unsupported event type "${input.eventType}".`);
    }

    const product = Products.findProduct(products, input.productId);
    const code = input.productId === undefined || input.productId === null ? '' : String(input.productId);
    if (!check('product', !!product, product ? `${product.id} · ${product.name}` : `No match for "${code}"`)) {
      return finish(EVENT_STATUS.REJECTED, `Event rejected: unknown product ID "${code}".`);
    }
    if (!check('quantity', Cart.isPositiveInteger(input.quantity), String(input.quantity))) {
      return finish(EVENT_STATUS.REJECTED, 'Event rejected: quantity must be a whole number greater than zero.', product);
    }

    const adding = input.eventType === EVENT_TYPES.ADDED;
    const outcome = adding
      ? Cart.addItem(cart, product, input.quantity)
      : Cart.removeItem(cart, product, input.quantity);
    const ruleLabel = adding ? 'Stock available' : 'Item is in the trolley';
    if (!check('cartRule', outcome.ok, outcome.ok ? 'OK' : outcome.message, ruleLabel)) {
      return finish(EVENT_STATUS.REJECTED, `Event rejected: ${outcome.message}`, product);
    }
    return finish(EVENT_STATUS.ACCEPTED, outcome.message, product, outcome.cart);
  }

  const Sensor = {
    EVENT_TYPES,
    EVENT_STATUS,
    CHECKS,
    createSensorState,
    isValidSensorState,
    formatEventId,
    createEvent,
    processEvent,
  };

  ns.Sensor = Sensor;
  if (typeof module === 'object' && module.exports) module.exports = Sensor;
})(typeof globalThis !== 'undefined' ? globalThis : this);
