/*
 * Hardware screen. Each action is sent through the real sensor pipeline immediately, then replayed
 * step by step: the screen holds back the LCD, basket and weight until the matching step is reached.
 */
(function () {
  'use strict';

  const { Products, Cart, Billing, Hardware, App } = window.SmartTrolley;
  const el = (id) => document.getElementById(id);
  const esc = App.escapeHtml;
  const money = Billing.formatPaise;

  const SPEEDS = { slow: 1100, normal: 550, fast: 180, instant: 0 };
  const MAX_SERIAL_LINES = 300;
  const MAX_BASKET_ICONS = 14;
  const PHASES = [
    { id: 'sense', title: 'Sense', subtitle: 'Sensors build a packet' },
    { id: 'firmware', title: 'Validate', subtitle: 'Firmware checks the packet' },
    { id: 'output', title: 'Respond', subtitle: 'Cart, bill, display, buzzer' },
  ];
  const STATUS_ICONS = { pass: '✓', fail: '✕', warn: '!', info: 'i', skip: '–', pending: '' };
  const LED_LABELS = { off: 'Idle', green: 'Green: accepted', amber: 'Amber: ignored', red: 'Red: error' };

  const view = {
    productId: null,
    fault: 'none',
    speed: 'normal',
    running: false,
    skip: false,
    trace: null,
    shown: 0,
    active: null,
    serial: [],
    serialClock: 0, // simulated ms already used in the serial log, so timestamps never go backwards
    lcdHold: null,
    basketHold: null,
    weightHold: null,
    lastTag: null,
    irState: 'clear',
    led: 'off',
  };

  function timestamp(ms) {
    return `[${String(Math.round(ms)).padStart(8)} ms]`;
  }

  function log(line) {
    view.serial.push(line);
    if (view.serial.length > MAX_SERIAL_LINES) view.serial.splice(0, view.serial.length - MAX_SERIAL_LINES);
  }

  function selectedProduct() {
    const { products } = App.getState();
    return Products.findProduct(products, view.productId) || products[0];
  }

  /* ---------- Rendering ---------- */

  function renderAll() {
    renderControls();
    renderStage();
    renderComponents();
    renderPipeline();
    renderLcd();
    renderSerial();
  }

  function renderControls() {
    const state = App.getState();
    const select = el('hw-product');
    if (!view.productId) view.productId = state.products[0].id;
    if (document.activeElement !== select) {
      select.innerHTML = state.products.map((p) =>
        `<option value="${esc(p.id)}">${esc(p.icon || '')} ${esc(p.name)} · ${money(p.pricePaise)}</option>`).join('');
      select.value = view.productId;
    }
    const product = selectedProduct();
    const inCart = Cart.getQuantity(state.cart, product.id);
    el('hw-product-info').innerHTML =
      `<span>Code <code>${esc(product.barcode)}</code></span><span>${Hardware.weightOf(product.id)} g</span>` +
      `<span>${product.stock - inCart} on shelf</span><span>${inCart} in trolley</span>`;
    el('hw-place').disabled = view.running;
    el('hw-remove').disabled = view.running;
    el('hw-product').disabled = view.running;
    el('hw-fault').disabled = view.running;
    el('hw-skip').disabled = !view.running;
    el('hw-fault').classList.toggle('is-armed', view.fault !== 'none');
  }

  function renderStage() {
    const state = App.getState();
    const cart = view.basketHold || state.cart;
    const icons = [];
    cart.items.forEach((item) => {
      const product = Products.findProduct(state.products, item.productId);
      for (let i = 0; i < item.quantity; i += 1) icons.push(product && product.icon ? product.icon : '🛍️');
    });
    const extra = icons.length - MAX_BASKET_ICONS;
    el('hw-basket').innerHTML = icons.slice(0, MAX_BASKET_ICONS).map((icon) => `<span>${esc(icon)}</span>`).join('') +
      (extra > 0 ? `<span class="hw-more">+${extra}</span>` : '');

    const stage = el('hw-stage');
    stage.dataset.ir = view.irState;
    stage.dataset.led = view.led;
    document.querySelectorAll('#view-hardware [data-part]').forEach((node) => {
      const active = !!view.active && view.active.component === node.dataset.part;
      node.classList.toggle('is-active', active);
      node.classList.toggle('is-fail', active && view.active.status === 'fail');
    });
  }

  function componentReading(id, state) {
    const weight = view.weightHold !== null ? view.weightHold : Hardware.cartWeight(state.cart);
    switch (id) {
      case 'ir': return view.irState === 'broken' ? 'Beam broken' : 'Beam clear';
      case 'reader': return view.lastTag ? `Last code ${view.lastTag}` : 'Waiting for a code';
      case 'loadcell': return `${(weight / 1000).toFixed(3)} kg on platform`;
      case 'mcu': return `${state.sensor.sequence} packets sent`;
      case 'db': return `${state.products.length} products loaded`;
      case 'lcd': return 'I²C address 0x27';
      case 'buzzer': return LED_LABELS[view.led];
      default: return '';
    }
  }

  function renderComponents() {
    const state = App.getState();
    el('hw-components').innerHTML = Hardware.COMPONENTS.map((part, index) => {
      const active = !!view.active && view.active.component === part.id;
      const fail = active && view.active.status === 'fail';
      return `<li class="hw-comp${active ? ' is-active' : ''}${fail ? ' is-fail' : ''}" data-part="${part.id}">
        <span class="hw-num">${index + 1}</span>
        <div>
          <strong>${esc(part.name)}</strong>
          <small>${esc(part.part)} · ${esc(part.role)}</small>
          <span class="hw-reading">${esc(componentReading(part.id, state))}</span>
        </div>
      </li>`;
    }).join('');
  }

  function stepHtml(step) {
    const shown = step.index < view.shown;
    const status = shown ? step.status : 'pending';
    const current = view.running && step.index === view.shown - 1;
    return `<li class="hw-step st-${status}${current ? ' is-current' : ''}">
      <span class="hw-step-icon" aria-hidden="true">${STATUS_ICONS[status]}</span>
      <div class="hw-step-body">
        <strong>${esc(step.title)}</strong>
        ${shown ? `<small>${esc(step.detail)}</small>` : ''}
      </div>
      <span class="hw-step-ms">${shown && step.status !== 'skip' ? `${step.atMs} ms` : ''}</span>
    </li>`;
  }

  function renderPipeline() {
    const trace = view.trace;
    const outcome = el('hw-outcome');
    if (!trace) {
      outcome.textContent = 'Idle';
      outcome.className = 'pill';
      el('hw-pipeline').innerHTML = `<div class="hw-phases">${PHASES.map((phase, i) => `<section class="hw-phase">
          <header><span class="hw-phase-num">${i + 1}</span><div><h3>${phase.title}</h3><small>${phase.subtitle}</small></div></header>
        </section>`).join('')}</div>
        <p class="empty-state">Pick a product and press <strong>Place in trolley</strong>. Each stage lights up as the item is processed.</p>`;
      return;
    }

    const done = view.shown >= trace.steps.length && !view.running;
    outcome.textContent = done ? `${trace.outcome} · ${trace.totalMs} ms` : 'Processing…';
    outcome.className = `pill${done ? ` outcome-${trace.outcome.toLowerCase()}` : ' outcome-running'}`;

    const steps = trace.steps.map((step, index) => ({ ...step, index }));
    const packetStep = steps.find((step) => step.packet && step.index < view.shown);
    el('hw-pipeline').innerHTML = `<div class="hw-phases">${PHASES.map((phase, i) => {
      const phaseSteps = steps.filter((step) => step.phase === phase.id);
      return `<section class="hw-phase">
        <header><span class="hw-phase-num">${i + 1}</span><div><h3>${phase.title}</h3><small>${phase.subtitle}</small></div></header>
        <ol class="hw-steps">${phaseSteps.map(stepHtml).join('')}</ol>
        ${phase.id === 'sense' && packetStep ? `<pre class="hw-packet" aria-label="Event packet">${esc(JSON.stringify(packetStep.packet, null, 2))}</pre>` : ''}
      </section>`;
    }).join('')}</div>
    ${done ? `<p class="hw-result outcome-${trace.outcome.toLowerCase()}">${esc(trace.message)}</p>` : ''}`;
  }

  function renderLcd() {
    const lcd = view.lcdHold || App.lcdMarkup();
    el('hw-lcd').dataset.tone = lcd.tone;
    el('hw-lcd-screen').innerHTML = lcd.html;
    el('hw-lcd-caption').textContent = lcd.caption;
  }

  function renderSerial() {
    const serial = el('hw-serial');
    serial.textContent = view.serial.join('\n');
    serial.scrollTop = serial.scrollHeight;
  }

  /* ---------- Animation ---------- */

  function fly(mode, icon) {
    const flyer = el('hw-flyer');
    flyer.textContent = icon;
    flyer.style.setProperty('--fly-ms', `${Math.max(SPEEDS[view.speed] * 1.6, 260)}ms`);
    flyer.className = 'hw-flyer';
    void flyer.offsetWidth; // restart the CSS animation
    flyer.className = `hw-flyer fly-${mode}`;
  }

  function applyEffects(step, ctx) {
    switch (step.kind) {
      case 'gate':
        view.irState = 'broken';
        if (ctx.reading.weightCheck === 'fail') fly('hover', ctx.icon);
        else fly(ctx.reading.action === 'place' ? 'in' : 'out', ctx.icon);
        break;
      case 'scan':
        view.irState = 'clear';
        view.lastTag = ctx.reading.tag;
        break;
      case 'weigh':
        view.weightHold = ctx.weightBefore + ctx.reading.measuredDeltaG;
        break;
      case 'cart':
        if (step.status === 'pass') view.basketHold = null;
        break;
      case 'lcd':
        view.lcdHold = null;
        break;
      case 'buzzer':
        view.led = step.led;
        break;
      default:
        break;
    }
  }

  function animate(trace, ctx) {
    return new Promise((resolve) => {
      view.trace = trace;
      view.shown = 0;
      view.led = 'off';
      const start = Math.max(performance.now(), view.serialClock + 1);
      view.serialClock = start + trace.totalMs;
      log(`${timestamp(start)} ---- ${ctx.label} ----`);

      const next = () => {
        if (view.shown >= trace.steps.length) {
          view.active = null;
          view.weightHold = null;
          view.basketHold = null;
          view.lcdHold = null;
          // An item that went in but was not billed has to come back out.
          if (ctx.reading && ctx.reading.action === 'place' && ctx.reading.weightCheck !== 'fail' && trace.outcome !== 'ACCEPTED') {
            fly('reject', ctx.icon);
          }
          renderAll();
          resolve();
          return;
        }
        const step = trace.steps[view.shown];
        view.shown += 1;
        view.active = step;
        applyEffects(step, ctx);
        if (step.serial) log(`${timestamp(start + step.atMs)} ${step.serial}`);
        renderAll();
        setTimeout(next, view.skip ? 0 : SPEEDS[view.speed]);
      };
      next();
    });
  }

  // Captures what the screen should keep showing until the matching step is animated.
  function hold() {
    const state = App.getState();
    view.lcdHold = App.lcdMarkup();
    view.basketHold = state.cart;
    view.weightHold = Hardware.cartWeight(state.cart);
    return { cartBefore: state.cart, weightBefore: view.weightHold, settings: state.settings };
  }

  function detect(action, product, fault) {
    const before = hold();
    const reading = Hardware.readSensors({ action, product, cart: before.cartBefore, fault });
    let event = null;
    let result = null;
    if (reading.forward) {
      ({ event, result } = App.sendEvent(reading.eventType, reading.tag, reading.quantity));
    } else {
      App.showAlert({ tone: 'error', status: 'CHECK', detail: 'WEIGHT MISMATCH', message: 'Scan discarded: weight did not match the scanned product.' });
    }
    const trace = Hardware.buildTrace({ reading, event, result, cartBefore: before.cartBefore, settings: before.settings, product });
    const label = `${action === 'place' ? 'PLACE' : 'TAKE OUT'} ${product.name.toUpperCase()}`;
    return animate(trace, { ...before, reading, icon: product.icon || '🛍️', label }).then(() => event);
  }

  function retransmit(event, product) {
    const before = hold();
    const resent = { ...event, timestamp: new Date().toISOString() };
    const result = App.applyEvent(resent);
    const trace = Hardware.buildTrace({ reading: null, event: resent, result, cartBefore: before.cartBefore, settings: before.settings, product, retransmit: true });
    return animate(trace, { ...before, reading: null, icon: product.icon || '🛍️', label: `RETRANSMIT ${event.eventId}` });
  }

  async function run(action) {
    if (view.running) return;
    const product = selectedProduct();
    const doubleFire = view.fault === 'doubleFire';
    view.running = true;
    view.skip = false;
    try {
      const event = await detect(action, product, doubleFire ? 'none' : view.fault);
      if (doubleFire && event) await retransmit(event, product);
    } finally {
      view.running = false;
      view.active = null;
      view.irState = 'clear';
      renderAll();
    }
  }

  /* ---------- Wiring ---------- */

  function bootLog() {
    const { products } = App.getState();
    const t = performance.now();
    [
      'BOOT    SmartCart trolley firmware v1.0 (simulated)',
      'I2C     LCD 20x4 found at 0x27',
      'HX711   load cell tared',
      'READER  ready on UART, 9600 baud',
      `DB      ${products.length} products loaded`,
      'READY   waiting for items',
    ].forEach((line, i) => log(`${timestamp(t + i)} ${line}`));
    view.serialClock = t + 5;
  }

  function init() {
    el('hw-fault').innerHTML = Object.keys(Hardware.FAULTS)
      .map((key) => `<option value="${key}">${esc(Hardware.FAULTS[key])}</option>`).join('');

    el('view-hardware').addEventListener('click', (event) => {
      const target = event.target.closest('[data-hw]');
      if (!target || target.disabled) return;
      const action = target.dataset.hw;
      if (action === 'place' || action === 'remove') run(action === 'place' ? 'place' : 'remove');
      if (action === 'skip') view.skip = true;
      if (action === 'clear-serial') {
        view.serial = [];
        renderSerial();
      }
    });
    el('hw-product').addEventListener('change', (event) => {
      view.productId = event.target.value;
      renderControls();
    });
    el('hw-fault').addEventListener('change', (event) => {
      view.fault = event.target.value;
      renderControls();
    });
    el('hw-speed').addEventListener('change', (event) => {
      view.speed = event.target.value;
    });

    bootLog();
    App.onRender(renderAll);
    renderAll();
  }

  init();
})();
