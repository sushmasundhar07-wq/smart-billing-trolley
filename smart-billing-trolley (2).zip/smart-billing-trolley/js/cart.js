/* Trolley state. Every operation is pure: it returns a new cart and never mutates the one passed in. */
(function (global) {
  'use strict';

  const ns = global.SmartTrolley || (global.SmartTrolley = {});

  function createCart() {
    return { items: [] };
  }

  function isPositiveInteger(value) {
    return Number.isInteger(value) && value > 0;
  }

  function findItem(cart, productId) {
    return cart.items.find((item) => item.productId === productId) || null;
  }

  function getQuantity(cart, productId) {
    const item = findItem(cart, productId);
    return item ? item.quantity : 0;
  }

  function success(cart, message) {
    return { ok: true, cart, message };
  }

  function failure(cart, message) {
    return { ok: false, cart, message };
  }

  function quantityLabel(quantity, name) {
    return quantity > 1 ? `${quantity} × ${name}` : name;
  }

  function addItem(cart, product, quantity) {
    const qty = quantity === undefined ? 1 : quantity;
    if (!product) return failure(cart, 'Unknown product.');
    if (!isPositiveInteger(qty)) return failure(cart, 'Quantity must be a whole number greater than zero.');

    const current = getQuantity(cart, product.id);
    if (current + qty > product.stock) {
      const left = product.stock - current;
      return failure(cart, left > 0
        ? `Only ${left} more ${product.name} available.`
        : `${product.name} is out of stock.`);
    }

    const items = current > 0
      ? cart.items.map((item) => (item.productId === product.id ? { ...item, quantity: item.quantity + qty } : item))
      : cart.items.concat({
        productId: product.id,
        name: product.name,
        category: product.category,
        unitPricePaise: product.pricePaise,
        quantity: qty,
      });
    return success({ items }, `${quantityLabel(qty, product.name)} added to trolley.`);
  }

  function removeItem(cart, product, quantity) {
    const qty = quantity === undefined ? 1 : quantity;
    if (!product) return failure(cart, 'Unknown product.');
    if (!isPositiveInteger(qty)) return failure(cart, 'Quantity must be a whole number greater than zero.');

    const current = getQuantity(cart, product.id);
    if (current === 0) return failure(cart, `${product.name} is not in the trolley.`);
    if (qty > current) return failure(cart, `Cannot remove ${qty} ${product.name}; only ${current} in trolley.`);

    const items = qty === current
      ? cart.items.filter((item) => item.productId !== product.id)
      : cart.items.map((item) => (item.productId === product.id ? { ...item, quantity: item.quantity - qty } : item));
    return success({ items }, `${quantityLabel(qty, product.name)} removed from trolley.`);
  }

  function totalUnits(cart) {
    return cart.items.reduce((sum, item) => sum + item.quantity, 0);
  }

  function uniqueProducts(cart) {
    return cart.items.length;
  }

  function isValidCart(cart) {
    return !!cart && Array.isArray(cart.items) && cart.items.every((item) =>
      !!item &&
      typeof item.productId === 'string' &&
      typeof item.name === 'string' &&
      typeof item.category === 'string' &&
      Number.isInteger(item.unitPricePaise) && item.unitPricePaise >= 0 &&
      isPositiveInteger(item.quantity));
  }

  const Cart = {
    createCart,
    isPositiveInteger,
    getQuantity,
    addItem,
    removeItem,
    totalUnits,
    uniqueProducts,
    isValidCart,
  };

  ns.Cart = Cart;
  if (typeof module === 'object' && module.exports) module.exports = Cart;
})(typeof globalThis !== 'undefined' ? globalThis : this);
