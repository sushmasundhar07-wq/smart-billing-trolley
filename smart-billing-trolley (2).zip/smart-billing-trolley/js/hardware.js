/*
 * Hardware layer model. Simulates what the trolley's physical parts would report for one action
 * (IR gate, code reader, load cell) and builds a step-by-step trace of how that detection travels
 * through the firmware to the cart, bill, LCD and buzzer. Every reading here is simulated.
 */
(function (global) {
  'use strict';

  const ns = global.SmartTrolley || (global.SmartTrolley = {});
  const Cart = ns.Cart || require('./cart.js');
  const Billing = ns.Billing || require('./billing.js');
  const Sensor = ns.Sensor || require('./sensor.js');

  const COMPONENTS = Object.freeze([
    { id: 'ir', name: 'IR gate sensor', part: 'IR break-beam pair', role: 'Detects an item crossing the basket rim' },
    { id: 'reader', name: 'Code reader', part: 'Barcode / RFID module (UART)', role: 'Reads the product code' },
    { id: 'loadcell', name: 'Load cell', part: 'Load cell + HX711 ADC', role: 'Confirms the weight change' },
    { id: 'mcu', name: 'Microcontroller', part: 'ESP32 firmware', role: 'Builds the event, validates it, updates cart and bill' },
    { id: 'db', name: 'Product database', part: 'Catalog in flash memory', role: 'Looks up product, price and stock' },
    { id: 'lcd', name: 'LCD display', part: '20×4 character LCD (I²C)', role: 'Shows status and running total' },
    { id: 'buzzer', name: 'Buzzer + LED', part: 'Piezo buzzer, RGB LED', role: 'Confirms or warns the shopper' },
  ]);

  const FAULTS = Object.freeze({
    none: 'No fault',
    unknownTag: 'Unknown product code',
    notPlaced: 'Scanned but not placed (weight mismatch)',
    badQuantity: 'Corrupted packet (quantity 0)',
    doubleFire: 'Sensor double-fire (duplicate packet)',
  });

  const WEIGHT_TOLERANCE = 0.05;
  const DEFAULT_WEIGHT_G = 500;
  // Reference weights in grams; products not listed use DEFAULT_WEIGHT_G.
  const WEIGHTS_G = Object.freeze({
    P001: 520, P002: 400, P003: 1010, P004: 1200, P005: 1000, P006: 720, P007: 105, P008: 1000, P009: 1000,
    P010: 1000, P011: 1060, P012: 255, P013: 120, P014: 55, P015: 1000, P016: 540, P017: 200,
  });

  // Simulated time each stage takes on real hardware, in milliseconds (HX711 settling dominates).
  const STEP_MS = Object.freeze({
    gate: 0, scan: 15, weigh: 180, packet: 4, retransmit: 30, discard: 1, check: 1,
    cart: 1, bill: 1, lcd: 12, buzzer: 1,
  });

  function weightOf(productId) {
    return WEIGHTS_G[productId] || DEFAULT_WEIGHT_G;
  }

  function cartWeight(cart) {
    return cart.items.reduce((sum, item) => sum + weightOf(item.productId) * item.quantity, 0);
  }

  function signedGrams(grams) {
    return `${grams > 0 ? '+' : ''}${grams} g`;
  }

  /*
   * Simulates the physical sensor readings for placing a product in, or taking it out of, the trolley.
   * forward is false when the weight cross-check fails: the hardware then discards the scan and no
   * event reaches the firmware validator.
   */
  function readSensors({ action, product, cart, fault, random }) {
    const rand = random || Math.random;
    const placing = action === 'place';
    const unknownTag = fault === 'unknownTag';
    const tag = unknownTag ? `20000000${Math.floor(rand() * 90000) + 10000}` : product.barcode;
    const expected = (placing ? 1 : -1) * weightOf(product.id);
    // Nothing physically moves if the item was not placed, or if it was never in the trolley to take out.
    const moved = fault !== 'notPlaced' && (placing || Cart.getQuantity(cart, product.id) > 0);
    const measured = moved
      ? Math.round(expected * (1 + (rand() * 2 - 1) * 0.015))
      : Math.round((rand() * 2 - 1) * 4);

    let weightCheck = 'unchecked';
    if (!unknownTag) weightCheck = Math.abs(measured - expected) <= Math.abs(expected) * WEIGHT_TOLERANCE ? 'pass' : 'fail';

    return {
      action,
      gate: placing ? 'entry' : 'exit',
      tag,
      expectedDeltaG: unknownTag ? null : expected,
      measuredDeltaG: measured,
      weightCheck,
      forward: weightCheck !== 'fail',
      eventType: placing ? Sensor.EVENT_TYPES.ADDED : Sensor.EVENT_TYPES.REMOVED,
      quantity: fault === 'badQuantity' ? 0 : 1,
    };
  }

  /*
   * Builds the ordered trace for one detection. Pass reading=null with retransmit=true for a packet
   * the reader re-sent. result is Sensor.processEvent's output, or null when the hardware discarded it.
   */
  function buildTrace({ reading, event, result, cartBefore, settings, product, retransmit }) {
    const steps = [];
    let atMs = 0;
    function add(kind, step) {
      atMs += STEP_MS[kind];
      steps.push({ kind, atMs, ...step });
    }

    if (retransmit) {
      add('retransmit', {
        phase: 'sense', component: 'reader', status: 'warn', title: 'Packet re-sent by reader',
        detail: `Reader bounced and transmitted ${event.eventId} a second time.`,
        serial: `READER  bounce -> resend ${event.eventId}`,
      });
    } else {
      const placing = reading.action === 'place';
      add('gate', {
        phase: 'sense', component: 'ir', status: 'pass',
        title: placing ? 'Item crosses entry gate' : 'Item crosses exit gate',
        detail: 'IR beam interrupted at the basket rim.',
        serial: `IR      beam broken (${reading.gate})`,
      });
      add('scan', {
        phase: 'sense', component: 'reader', status: 'pass', title: 'Product code read',
        detail: `Code ${reading.tag}`,
        serial: `READER  code=${reading.tag}`,
      });

      const measured = signedGrams(reading.measuredDeltaG);
      let weighDetail = `Measured ${measured}; no reference weight for this code, so the firmware decides.`;
      if (reading.weightCheck === 'pass') weighDetail = `Measured ${measured}, expected ${signedGrams(reading.expectedDeltaG)} ±5%.`;
      if (reading.weightCheck === 'fail') {
        weighDetail = `Measured ${measured}, expected ${signedGrams(reading.expectedDeltaG)}. The item was not ${placing ? 'placed in' : 'taken out of'} the trolley.`;
      }
      add('weigh', {
        phase: 'sense', component: 'loadcell',
        status: { pass: 'pass', fail: 'fail', unchecked: 'info' }[reading.weightCheck],
        title: 'Weight change measured', detail: weighDetail,
        serial: `HX711   delta=${reading.measuredDeltaG}g ${reading.expectedDeltaG === null ? 'ref=none' : `exp=${reading.expectedDeltaG}g`} ${reading.weightCheck.toUpperCase()}`,
      });

      if (!reading.forward) {
        add('discard', {
          phase: 'firmware', component: 'mcu', status: 'fail', title: 'Scan discarded by hardware check',
          detail: 'Code and weight disagree, so no event was sent to the validator.',
          serial: 'MCU     weight mismatch -> scan discarded',
        });
      } else {
        add('packet', {
          phase: 'sense', component: 'mcu', status: 'pass', title: 'Event packet built',
          detail: `${event.eventId} · ${event.eventType} · qty ${event.quantity}`,
          serial: `MCU     packet ${event.eventId} ${event.eventType} code=${event.productId} qty=${event.quantity}`,
          packet: event,
        });
      }
    }

    if (result) {
      Sensor.CHECKS.forEach((definition) => {
        const ran = result.checks.find((c) => c.id === definition.id);
        add('check', {
          phase: 'firmware',
          component: definition.id === 'product' ? 'db' : 'mcu',
          status: ran ? (ran.ok ? 'pass' : 'fail') : 'skip',
          title: ran ? ran.label : definition.label,
          detail: ran ? ran.detail : 'Not run: an earlier check failed.',
          serial: ran ? `FW      ${ran.label.toLowerCase()}: ${ran.ok ? 'OK' : 'FAIL'}` : null,
        });
      });
    }

    const accepted = !!result && result.status === Sensor.EVENT_STATUS.ACCEPTED;
    if (accepted) {
      const before = Billing.calculateBill(cartBefore.items, settings);
      const after = Billing.calculateBill(result.cart.items, settings);
      const qtyBefore = Cart.getQuantity(cartBefore, product.id);
      const qtyAfter = Cart.getQuantity(result.cart, product.id);
      add('cart', {
        phase: 'output', component: 'mcu', status: 'pass', title: 'Trolley updated',
        detail: `${product.name}: ${qtyBefore} → ${qtyAfter}`,
        serial: `CART    ${product.id} qty ${qtyBefore}->${qtyAfter}`,
      });
      add('bill', {
        phase: 'output', component: 'mcu', status: 'pass', title: 'Bill recalculated',
        detail: `${Billing.formatPaise(before.grandTotalPaise)} → ${Billing.formatPaise(after.grandTotalPaise)}`,
        serial: `BILL    total ${before.grandTotalPaise}->${after.grandTotalPaise} paise`,
      });
    } else {
      add('cart', { phase: 'output', component: 'mcu', status: 'skip', title: 'Trolley unchanged', detail: 'Nothing is applied when a scan is rejected.', serial: null });
      add('bill', { phase: 'output', component: 'mcu', status: 'skip', title: 'Bill unchanged', detail: 'The total stays the same.', serial: null });
    }

    const duplicate = !!result && result.status === Sensor.EVENT_STATUS.DUPLICATE;
    let outcome = 'DISCARDED';
    if (result) outcome = result.status;
    const message = result ? result.message : 'Scan discarded: weight did not match the scanned product.';

    add('lcd', {
      phase: 'output', component: 'lcd', status: accepted ? 'pass' : 'warn',
      title: accepted ? 'Display refreshed' : 'Warning shown on display',
      detail: accepted ? 'Status line and running total updated.' : message,
      serial: `LCD     status=${outcome}`,
    });
    add('buzzer', {
      phase: 'output', component: 'buzzer',
      status: accepted ? 'pass' : duplicate ? 'warn' : 'fail',
      title: accepted ? 'Confirmation beep' : duplicate ? 'Ignored quietly' : 'Error tone',
      detail: accepted ? 'Short beep, green LED.' : duplicate ? 'No beep, amber LED.' : 'Double beep, red LED.',
      serial: accepted ? 'BUZZER  beep 80ms, LED green' : duplicate ? 'BUZZER  silent, LED amber' : 'BUZZER  beep-beep, LED red',
      led: accepted ? 'green' : duplicate ? 'amber' : 'red',
    });

    return { steps, outcome, message, totalMs: atMs };
  }

  const Hardware = {
    COMPONENTS,
    FAULTS,
    WEIGHT_TOLERANCE,
    weightOf,
    cartWeight,
    readSensors,
    buildTrace,
  };

  ns.Hardware = Hardware;
  if (typeof module === 'object' && module.exports) module.exports = Hardware;
})(typeof globalThis !== 'undefined' ? globalThis : this);
