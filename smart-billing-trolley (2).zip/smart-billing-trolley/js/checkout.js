/* Checkout: validation, transaction snapshots, stock deduction and plain-text receipts. */
(function (global) {
  'use strict';

  const ns = global.SmartTrolley || (global.SmartTrolley = {});
  const Products = ns.Products || require('./products.js');
  const Cart = ns.Cart || require('./cart.js');
  const Billing = ns.Billing || require('./billing.js');

  const STORE_NAME = 'SmartCart Supermarket';
  const RECEIPT_WIDTH = 40;

  function validateCheckout(cart, products) {
    if (!cart || !Array.isArray(cart.items) || cart.items.length === 0) {
      return { ok: false, errors: ['The trolley is empty. Add at least one product before checkout.'] };
    }
    const errors = [];
    cart.items.forEach((item) => {
      const product = Products.findProduct(products, item.productId);
      if (!product) errors.push(`${item.name} is no longer in the catalog.`);
      else if (!Cart.isPositiveInteger(item.quantity)) errors.push(`${item.name} has an invalid quantity.`);
      else if (item.quantity > product.stock) errors.push(`Only ${product.stock} ${item.name} in stock.`);
    });
    return { ok: errors.length === 0, errors };
  }

  function pad2(value) {
    return String(value).padStart(2, '0');
  }

  // TXN-YYYYMMDD-HHMMSS-XXXX, with a random base-36 suffix re-drawn until it is unique.
  function generateTransactionId(now, existingIds, random) {
    const rand = random || Math.random;
    const stamp = `${now.getFullYear()}${pad2(now.getMonth() + 1)}${pad2(now.getDate())}` +
      `-${pad2(now.getHours())}${pad2(now.getMinutes())}${pad2(now.getSeconds())}`;
    const taken = new Set(existingIds || []);
    for (let attempt = 0; attempt < 1000; attempt += 1) {
      const suffix = Math.floor(rand() * 36 ** 4).toString(36).toUpperCase().padStart(4, '0');
      const id = `TXN-${stamp}-${suffix}`;
      if (!taken.has(id)) return id;
    }
    throw new Error('Could not generate a unique transaction ID.');
  }

  /*
   * Completes checkout without mutating its inputs. The transaction stores a copy of every line,
   * including unit prices and tax rates, so later catalog changes never alter a past receipt.
   */
  function completeCheckout({ cart, products, settings, transactions, now, random }) {
    const validation = validateCheckout(cart, products);
    if (!validation.ok) return { ok: false, errors: validation.errors };

    const time = now || new Date();
    const bill = Billing.calculateBill(cart.items, settings);
    const history = transactions || [];
    const transaction = {
      transactionId: generateTransactionId(time, history.map((t) => t.transactionId), random),
      createdAt: time.toISOString(),
      status: 'COMPLETED',
      items: bill.lines.map((line) => ({ ...line })),
      totalUnits: bill.totalUnits,
      subtotalPaise: bill.subtotalPaise,
      taxPaise: bill.taxPaise,
      discountPaise: bill.discountPaise,
      grandTotalPaise: bill.grandTotalPaise,
      discount: { ...bill.discount },
    };

    const nextProducts = products.map((product) => {
      const quantity = Cart.getQuantity(cart, product.id);
      return quantity > 0 ? { ...product, stock: product.stock - quantity } : product;
    });

    return {
      ok: true,
      transaction,
      cart: Cart.createCart(),
      products: nextProducts,
      transactions: [transaction].concat(history),
    };
  }

  function isValidTransaction(transaction) {
    return !!transaction &&
      typeof transaction.transactionId === 'string' &&
      typeof transaction.createdAt === 'string' &&
      Array.isArray(transaction.items) &&
      Number.isInteger(transaction.grandTotalPaise);
  }

  function isValidTransactionList(list) {
    return Array.isArray(list) && list.every(isValidTransaction);
  }

  function formatDateTime(iso) {
    const date = new Date(iso);
    if (Number.isNaN(date.getTime())) return iso;
    return date.toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  }

  function amount(paise) {
    return Billing.formatPaise(paise).replace('₹', '');
  }

  function centre(text) {
    const space = Math.max(0, RECEIPT_WIDTH - text.length);
    return ' '.repeat(Math.floor(space / 2)) + text;
  }

  function twoColumns(left, right) {
    return left + right.padStart(RECEIPT_WIDTH - left.length);
  }

  function receiptText(transaction) {
    const rule = '-'.repeat(RECEIPT_WIDTH);
    const rows = transaction.items.map((line) => {
      const name = line.name.length > 18 ? `${line.name.slice(0, 17)}.` : line.name;
      return name.padEnd(18) + String(line.quantity).padStart(4) + amount(line.unitPricePaise).padStart(8) +
        amount(line.lineTotalPaise).padStart(10);
    });
    return [
      centre(STORE_NAME.toUpperCase()),
      centre('Smart Billing Trolley (Simulation)'),
      rule,
      `Txn:  ${transaction.transactionId}`,
      `Date: ${formatDateTime(transaction.createdAt)}`,
      rule,
      'Item'.padEnd(18) + 'Qty'.padStart(4) + 'Rate'.padStart(8) + 'Amount'.padStart(10),
      ...rows,
      rule,
      twoColumns(`Subtotal (${transaction.totalUnits} units)`, Billing.formatPaise(transaction.subtotalPaise)),
      twoColumns('Tax', Billing.formatPaise(transaction.taxPaise)),
      twoColumns(`Discount (${Billing.describeDiscount(transaction.discount)})`, `-${Billing.formatPaise(transaction.discountPaise)}`),
      twoColumns('TOTAL', Billing.formatPaise(transaction.grandTotalPaise)),
      rule,
      centre('Demo receipt - no payment was taken.'),
      '',
    ].join('\n');
  }

  const Checkout = {
    STORE_NAME,
    validateCheckout,
    generateTransactionId,
    completeCheckout,
    isValidTransaction,
    isValidTransactionList,
    formatDateTime,
    receiptText,
  };

  ns.Checkout = Checkout;
  if (typeof module === 'object' && module.exports) module.exports = Checkout;
})(typeof globalThis !== 'undefined' ? globalThis : this);
