/* UI layer: renders application state and turns user actions into simulated sensor events. */
(function () {
  'use strict';

  const { Products, Cart, Billing, Sensor, Checkout, Storage } = window.SmartTrolley;
  const { EVENT_TYPES, EVENT_STATUS } = Sensor;

  const VIEWS = ['shop', 'hardware', 'checkout', 'history'];
  const LCD_WIDTH = 20;
  const LOG_DISPLAY_LIMIT = 25;
  const LOW_STOCK = 5;

  const storage = Storage.createStorage();
  const state = {};
  const renderHooks = [];
  const money = Billing.formatPaise;
  const el = (id) => document.getElementById(id);

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, (char) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    }[char]));
  }

  function plural(count, word) {
    return `${count} ${word}${count === 1 ? '' : 's'}`;
  }

  /* ---------- State ---------- */

  function loadState() {
    state.products = storage.loadProducts();
    state.cart = storage.loadCart();
    state.sensor = storage.loadSensorState();
    state.transactions = storage.loadTransactions();
    state.settings = storage.loadSettings();
    state.query = '';
    state.category = Products.ALL_CATEGORIES;
    state.checkoutErrors = [];
    state.receiptId = null;
    state.lcd = state.cart.items.length
      ? { tone: 'ready', status: 'RESTORED', detail: 'TROLLEY RESTORED', message: 'Saved trolley restored.' }
      : lcdFromRecord(state.sensor.log[0]);
  }

  function lcdFromRecord(record) {
    if (!record) return { tone: 'ready', status: 'READY', detail: 'ADD AN ITEM', message: 'Ready. Add a product to start billing.' };
    const name = record.productName ? record.productName.toUpperCase() : `ID ${record.productId || '?'}`;
    if (record.status === EVENT_STATUS.ACCEPTED) {
      const added = record.eventType === EVENT_TYPES.ADDED;
      const qty = record.quantity > 1 ? ` X${record.quantity}` : '';
      return { tone: added ? 'added' : 'removed', status: added ? 'ADDED' : 'REMOVED', detail: `${added ? '+' : '-'} ${name}${qty}`, message: record.message };
    }
    return { tone: 'error', status: record.status, detail: name, message: record.message };
  }

  /* ---------- Sensor pipeline ---------- */

  function sendEvent(eventType, productId, quantity, eventId) {
    const created = Sensor.createEvent(state.sensor, eventType, productId, quantity, { eventId });
    state.sensor = created.sensorState;
    return { event: created.event, result: applyEvent(created.event) };
  }

  function applyEvent(event) {
    const result = Sensor.processEvent(event, { products: state.products, cart: state.cart, sensorState: state.sensor });
    state.cart = result.cart;
    state.sensor = result.sensorState;
    state.lcd = lcdFromRecord(result.record);
    state.checkoutErrors = [];
    if (result.status === EVENT_STATUS.ACCEPTED) state.receiptId = null;
    storage.saveCart(state.cart);
    storage.saveSensorState(state.sensor);
    render();
    return result;
  }

  function availableFor(product) {
    return product.stock - Cart.getQuantity(state.cart, product.id);
  }

  /* ---------- Rendering ---------- */

  function render() {
    const focusKey = document.activeElement && document.activeElement.dataset
      ? document.activeElement.dataset.focusKey
      : null;
    const bill = Billing.calculateBill(state.cart.items, state.settings);

    renderView();
    renderCategories();
    renderCatalog();
    renderLcd(bill);
    renderTrolley(bill);
    renderEventLog();
    renderCheckout(bill);
    renderHistory();
    renderBadges(bill);
    renderHooks.forEach((hook) => hook(bill));
    restoreFocus(focusKey);
  }

  function currentView() {
    const hash = window.location.hash.slice(1);
    return VIEWS.includes(hash) ? hash : 'shop';
  }

  function renderView() {
    const view = currentView();
    document.body.dataset.view = view;
    document.querySelectorAll('[data-view-panel]').forEach((panel) => {
      panel.hidden = panel.dataset.viewPanel !== view;
    });
    document.querySelectorAll('[data-view-link]').forEach((link) => {
      if (link.dataset.viewLink === view) link.setAttribute('aria-current', 'page');
      else link.removeAttribute('aria-current');
    });
  }

  function renderCategories() {
    const categories = [Products.ALL_CATEGORIES].concat(Products.getCategories(state.products));
    el('category-filters').innerHTML = categories.map((category) => {
      const value = escapeHtml(category);
      return `<button type="button" class="chip" data-action="category" data-category="${value}" ` +
        `data-focus-key="filter:category:${value}" aria-pressed="${category === state.category}">${value}</button>`;
    }).join('');
  }

  function stockInfo(product) {
    const available = availableFor(product);
    if (available <= 0) return { tone: 'out', text: product.stock > 0 ? 'All stock in trolley' : 'Out of stock' };
    if (available <= LOW_STOCK) return { tone: 'low', text: `Only ${available} left` };
    return { tone: 'in', text: `${available} in stock` };
  }

  function productCard(product) {
    const id = escapeHtml(product.id);
    const name = escapeHtml(product.name);
    const inCart = Cart.getQuantity(state.cart, product.id);
    const stock = stockInfo(product);
    const canAdd = availableFor(product) > 0;
    const actions = inCart > 0
      ? `<div class="stepper" role="group" aria-label="${name} in trolley">
          <button type="button" class="step-btn" data-action="remove" data-id="${id}" data-focus-key="catalog:remove:${id}" aria-label="Remove one ${name}">−</button>
          <span class="step-qty">${inCart}<span class="visually-hidden"> in trolley</span></span>
          <button type="button" class="step-btn" data-action="add" data-id="${id}" data-focus-key="catalog:add:${id}" aria-label="Add one ${name}"${canAdd ? '' : ' disabled'}>+</button>
        </div>`
      : `<button type="button" class="btn primary block" data-action="add" data-id="${id}" data-focus-key="catalog:add:${id}"${canAdd ? '' : ' disabled'}>${canAdd ? 'Add to trolley' : 'Unavailable'}</button>`;

    return `<article class="product-card${inCart ? ' in-cart' : ''}">
      <div class="product-top">
        <span class="product-icon" aria-hidden="true">${escapeHtml(product.icon || '🛍️')}</span>
        <span class="product-tag">${escapeHtml(product.category)}</span>
      </div>
      <h3 class="product-name">${name}</h3>
      <p class="product-price">${money(product.pricePaise)} <span>/ ${escapeHtml(product.unit)}</span></p>
      <p class="product-code"><span>${id}</span><span>${escapeHtml(product.barcode)}</span></p>
      <p class="stock stock-${stock.tone}">${stock.text}</p>
      <div class="product-actions">${actions}</div>
    </article>`;
  }

  function renderCatalog() {
    const matches = Products.searchProducts(state.products, state.query, state.category);
    el('catalog-count').textContent = `Showing ${matches.length} of ${state.products.length}`;
    if (matches.length === 0) {
      const where = state.category !== Products.ALL_CATEGORIES ? ` in ${escapeHtml(state.category)}` : '';
      const what = state.query.trim() ? ` match “${escapeHtml(state.query.trim())}”` : ' here';
      el('product-grid').innerHTML = `<p class="empty-state">No products${what}${where}.</p>`;
      return;
    }
    el('product-grid').innerHTML = matches.map(productCard).join('');
  }

  function lcdLine(left, right) {
    const tail = right || '';
    const room = LCD_WIDTH - tail.length - (tail ? 1 : 0);
    const head = left.length > room ? left.slice(0, room) : left;
    return head.padEnd(LCD_WIDTH - tail.length) + tail;
  }

  // Returns the LCD contents so the hardware screen can show (and hold back) the same display.
  function lcdMarkup(bill) {
    const totals = bill || Billing.calculateBill(state.cart.items, state.settings);
    const units = String(totals.totalUnits).padStart(2, '0');
    const items = String(state.cart.items.length).padStart(2, '0');
    const lines = [
      lcdLine('SMARTCART', state.lcd.status),
      lcdLine(state.lcd.detail),
      lcdLine(`UNITS:${units}`, `ITEMS:${items}`),
      lcdLine('TOTAL', money(totals.grandTotalPaise)),
    ];
    return {
      tone: state.lcd.tone,
      html: lines.map((line) =>
        `<div class="lcd-row">${Array.from(line).map((char) => `<span>${char === ' ' ? '&nbsp;' : escapeHtml(char)}</span>`).join('')}</div>`
      ).join(''),
      caption: `${state.lcd.message} ${plural(totals.totalUnits, 'unit')} · ${money(totals.grandTotalPaise)}`,
    };
  }

  function renderLcd(bill) {
    const lcd = lcdMarkup(bill);
    el('lcd').dataset.tone = lcd.tone;
    el('lcd-screen').innerHTML = lcd.html;
    el('lcd-caption').textContent = lcd.caption;
  }

  function summaryHtml(totals) {
    const discountNote = totals.discount && totals.discount.type !== 'none'
      ? ` <small>(${escapeHtml(Billing.describeDiscount(totals.discount))})</small>`
      : '';
    return `<dl class="summary">
      <div><dt>Subtotal</dt><dd>${money(totals.subtotalPaise)}</dd></div>
      <div><dt>Tax</dt><dd>${money(totals.taxPaise)}</dd></div>
      <div><dt>Discount${discountNote}</dt><dd>${totals.discountPaise ? `-${money(totals.discountPaise)}` : money(0)}</dd></div>
      <div class="grand"><dt>Grand total</dt><dd>${money(totals.grandTotalPaise)}</dd></div>
    </dl>`;
  }

  function renderTrolley(bill) {
    const count = state.cart.items.length;
    el('trolley-count').textContent = count ? `${plural(bill.totalUnits, 'unit')} · ${plural(count, 'item')}` : 'Empty';
    el('trolley-list').innerHTML = count
      ? bill.lines.map((line) => {
        const id = escapeHtml(line.productId);
        const name = escapeHtml(line.name);
        const product = Products.findProduct(state.products, line.productId);
        const canAdd = product && availableFor(product) > 0;
        return `<li class="trolley-row">
          <div class="row-main">
            <span class="row-name">${name}</span>
            <span class="row-sub">${money(line.unitPricePaise)} × ${line.quantity}</span>
          </div>
          <span class="row-total">${money(line.lineTotalPaise)}</span>
          <div class="row-actions">
            <button type="button" class="icon-btn" data-action="remove" data-id="${id}" data-focus-key="trolley:remove:${id}" aria-label="Remove one ${name}">−</button>
            <button type="button" class="icon-btn" data-action="add" data-id="${id}" data-focus-key="trolley:add:${id}" aria-label="Add one ${name}"${canAdd ? '' : ' disabled'}>+</button>
            <button type="button" class="icon-btn danger" data-action="clear-item" data-id="${id}" data-focus-key="trolley:clear:${id}" aria-label="Remove all ${name}">✕</button>
          </div>
        </li>`;
      }).join('')
      : '<li class="empty-state">Your trolley is empty. Add products to start automatic billing.</li>';
    el('trolley-summary').innerHTML = summaryHtml(bill);
    el('go-checkout').classList.toggle('is-disabled', count === 0);
    el('go-checkout').setAttribute('aria-disabled', String(count === 0));
    el('clear-trolley').disabled = count === 0;
  }

  function renderEventLog() {
    const log = state.sensor.log.slice(0, LOG_DISPLAY_LIMIT);
    el('replay-last').disabled = state.sensor.log.length === 0;
    el('event-log').innerHTML = log.length
      ? log.map((record) => {
        const time = new Date(record.timestamp);
        const quantity = record.quantity === undefined || record.quantity === null ? '—' : record.quantity;
        return `<li class="log-entry log-${record.status.toLowerCase()}">
          <span class="log-status">${escapeHtml(record.status)}</span>
          <span class="log-body">
            <code>${escapeHtml(record.eventId)}</code>
            <code>${escapeHtml(record.eventType || '—')}</code>
            <code>${escapeHtml(record.productId || '—')} ×${escapeHtml(quantity)}</code>
            <span class="log-message">${escapeHtml(record.message)}</span>
          </span>
          <time datetime="${escapeHtml(record.timestamp)}">${Number.isNaN(time.getTime()) ? '' : time.toLocaleTimeString()}</time>
        </li>`;
      }).join('')
      : '<li class="empty-state">No sensor events yet.</li>';
  }

  function renderCheckout(bill) {
    const receipt = state.receiptId && state.transactions.find((t) => t.transactionId === state.receiptId);
    el('checkout-receipt').hidden = !receipt;
    el('checkout-main').hidden = !!receipt;

    if (receipt) {
      const id = escapeHtml(receipt.transactionId);
      el('checkout-receipt').innerHTML = `<div class="success-banner" role="status">
          <span class="success-icon" aria-hidden="true">✓</span>
          <div><h1 tabindex="-1" id="receipt-heading">Checkout complete</h1><p>Transaction <strong>${id}</strong> has been saved to history.</p></div>
        </div>
        ${receiptHtml(receipt)}
        <div class="btn-row center">
          <button type="button" class="btn" data-action="print-receipt" data-txn="${id}">Print receipt</button>
          <button type="button" class="btn" data-action="download-receipt" data-txn="${id}">Download .txt</button>
          <a href="#shop" class="btn primary" data-action="new-session">Start new shopping session</a>
        </div>`;
      return;
    }

    el('checkout-review').innerHTML = bill.lines.length
      ? `<div class="table-wrap"><table class="bill-table">
          <thead><tr><th scope="col">Item</th><th scope="col" class="num">Qty</th><th scope="col" class="num">Rate</th><th scope="col" class="num">Tax</th><th scope="col" class="num">Amount</th></tr></thead>
          <tbody>${bill.lines.map((line) => `<tr>
            <th scope="row">${escapeHtml(line.name)}<small>${escapeHtml(line.category)} · ${escapeHtml(line.productId)}</small></th>
            <td class="num">${line.quantity}</td>
            <td class="num">${money(line.unitPricePaise)}</td>
            <td class="num">${line.taxPercent}%<small>${money(line.taxPaise)}</small></td>
            <td class="num">${money(line.lineTotalPaise)}</td>
          </tr>`).join('')}</tbody>
        </table></div>`
      : '<p class="empty-state">Your trolley is empty. <a href="#shop">Go back to the shop</a> to add products.</p>';
    el('checkout-summary').innerHTML = summaryHtml(bill);
    el('checkout-errors').innerHTML = state.checkoutErrors.map((error) => `<li>${escapeHtml(error)}</li>`).join('');
  }

  function receiptHtml(txn) {
    return `<article class="receipt" aria-label="Receipt ${escapeHtml(txn.transactionId)}">
      <header class="receipt-head">
        <strong>${escapeHtml(Checkout.STORE_NAME)}</strong>
        <span>Smart Billing Trolley · Simulation</span>
      </header>
      <dl class="receipt-meta">
        <div><dt>Transaction</dt><dd>${escapeHtml(txn.transactionId)}</dd></div>
        <div><dt>Date</dt><dd>${escapeHtml(Checkout.formatDateTime(txn.createdAt))}</dd></div>
        <div><dt>Status</dt><dd>${escapeHtml(txn.status)}</dd></div>
      </dl>
      <table class="receipt-table">
        <thead><tr><th scope="col">Item</th><th scope="col" class="num">Qty</th><th scope="col" class="num">Rate</th><th scope="col" class="num">Amount</th></tr></thead>
        <tbody>${txn.items.map((line) => `<tr>
          <td>${escapeHtml(line.name)}</td>
          <td class="num">${line.quantity}</td>
          <td class="num">${money(line.unitPricePaise)}</td>
          <td class="num">${money(line.lineTotalPaise)}</td>
        </tr>`).join('')}</tbody>
      </table>
      ${summaryHtml(txn)}
      <p class="receipt-foot">${plural(txn.totalUnits, 'unit')} · Demo receipt — no real payment was processed.</p>
    </article>`;
  }

  function renderHistory() {
    const txns = state.transactions;
    const total = txns.reduce((sum, txn) => sum + txn.grandTotalPaise, 0);
    const items = txns.map((txn) => {
      const id = escapeHtml(txn.transactionId);
      return `<details class="panel history-item">
        <summary>
          <span class="txn-id">${id}</span>
          <span class="muted">${escapeHtml(Checkout.formatDateTime(txn.createdAt))}</span>
          <span class="muted">${plural(txn.totalUnits, 'unit')}</span>
          <strong class="txn-total">${money(txn.grandTotalPaise)}</strong>
        </summary>
        <div class="history-body">
          ${receiptHtml(txn)}
          <div class="btn-row center">
            <button type="button" class="btn" data-action="print-receipt" data-txn="${id}">Print receipt</button>
            <button type="button" class="btn" data-action="download-receipt" data-txn="${id}">Download .txt</button>
          </div>
        </div>
      </details>`;
    }).join('');

    el('history-root').innerHTML = `<div class="section-head page-head">
        <div>
          <h1>Transaction history</h1>
          <p class="muted">${plural(txns.length, 'completed transaction')} · ${money(total)} total</p>
        </div>
        <button type="button" class="btn ghost small danger-text" data-action="clear-history"${txns.length ? '' : ' disabled'}>Clear history</button>
      </div>
      ${txns.length ? `<div class="history-list">${items}</div>` : '<p class="panel empty-state">No completed transactions yet. Finish a checkout to see receipts here.</p>'}`;
  }

  function renderBadges(bill) {
    const badge = el('tab-badge');
    badge.hidden = bill.totalUnits === 0;
    badge.textContent = String(bill.totalUnits);
    el('mobile-units').textContent = plural(bill.totalUnits, 'unit');
    el('mobile-total').textContent = money(bill.grandTotalPaise);
  }

  function restoreFocus(key) {
    if (!key) return;
    const [area, , id] = key.split(':');
    const candidates = [key, `${area}:add:${id}`, `${area}:remove:${id}`, `catalog:add:${id}`];
    for (const candidate of candidates) {
      const target = document.querySelector(`[data-focus-key="${CSS.escape(candidate)}"]`);
      if (target && !target.disabled) {
        target.focus();
        return;
      }
    }
  }

  /* ---------- Billing settings ---------- */

  function renderSettingsForm() {
    const settings = state.settings;
    el('tax-default').value = String(settings.defaultTaxPercent);
    el('tax-categories').innerHTML = Products.getCategories(state.products).map((category) => {
      const value = Object.prototype.hasOwnProperty.call(settings.categoryTaxPercent, category)
        ? settings.categoryTaxPercent[category]
        : '';
      return `<label class="field compact"><span>${escapeHtml(category)}</span>
        <input data-category="${escapeHtml(category)}" inputmode="decimal" autocomplete="off" value="${escapeHtml(value)}" placeholder="Default"></label>`;
    }).join('');
    el('discount-type').value = settings.discount.type;
    el('discount-value').value = settings.discount.type === 'flat'
      ? money(settings.discount.value).replace('₹', '').replace(/,/g, '')
      : settings.discount.type === 'percent' ? String(settings.discount.value) : '';
    el('discount-value').disabled = settings.discount.type === 'none';
  }

  function readSettingsForm() {
    const errors = [];
    const parsePercent = (raw, label) => {
      const text = raw.trim();
      if (!/^\d+(\.\d{1,2})?$/.test(text) || Number(text) > 100) {
        errors.push(`${label} must be a number from 0 to 100.`);
        return null;
      }
      return Number(text);
    };

    const settings = {
      defaultTaxPercent: parsePercent(el('tax-default').value, 'Default tax rate'),
      categoryTaxPercent: {},
      discount: { type: el('discount-type').value, value: 0 },
    };
    el('tax-categories').querySelectorAll('input[data-category]').forEach((input) => {
      if (input.value.trim() === '') return;
      settings.categoryTaxPercent[input.dataset.category] = parsePercent(input.value, `${input.dataset.category} tax rate`);
    });
    if (settings.discount.type === 'percent') {
      settings.discount.value = parsePercent(el('discount-value').value, 'Discount percentage');
    } else if (settings.discount.type === 'flat') {
      const paise = Billing.rupeesToPaise(el('discount-value').value);
      if (paise === null) errors.push('Flat discount must be an amount such as 50 or 49.50.');
      settings.discount.value = paise;
    }
    return { errors, settings };
  }

  function setSettingsMessage(text, isError) {
    const message = el('settings-message');
    message.textContent = text;
    message.classList.toggle('is-error', !!isError);
  }

  /* ---------- Checkout and receipts ---------- */

  function confirmCheckout() {
    const result = Checkout.completeCheckout({
      cart: state.cart,
      products: state.products,
      settings: state.settings,
      transactions: state.transactions,
    });
    if (!result.ok) {
      state.checkoutErrors = result.errors;
      state.lcd = { tone: 'error', status: 'BLOCKED', detail: 'CHECKOUT BLOCKED', message: result.errors[0] };
      render();
      return;
    }
    state.cart = result.cart;
    state.products = result.products;
    state.transactions = result.transactions;
    state.receiptId = result.transaction.transactionId;
    state.checkoutErrors = [];
    state.lcd = { tone: 'paid', status: 'PAID', detail: 'THANK YOU!', message: `Checkout complete: ${result.transaction.transactionId}.` };
    storage.saveCart(state.cart);
    storage.saveProducts(state.products);
    storage.saveTransactions(state.transactions);
    render();
    const heading = el('receipt-heading');
    if (heading) heading.focus();
  }

  function findTransaction(id) {
    return state.transactions.find((txn) => txn.transactionId === id) || null;
  }

  function printReceipt(id) {
    const txn = findTransaction(id);
    if (!txn) return;
    el('print-area').innerHTML = receiptHtml(txn);
    window.print();
  }

  function downloadReceipt(id) {
    const txn = findTransaction(id);
    if (!txn) return;
    const url = URL.createObjectURL(new Blob([Checkout.receiptText(txn)], { type: 'text/plain;charset=utf-8' }));
    const link = document.createElement('a');
    link.href = url;
    link.download = `${txn.transactionId}.txt`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 0);
  }

  /* ---------- Event wiring ---------- */

  function handleAction(action, target, event) {
    const id = target.dataset.id;
    switch (action) {
      case 'add':
        sendEvent(EVENT_TYPES.ADDED, id, 1);
        break;
      case 'remove':
        sendEvent(EVENT_TYPES.REMOVED, id, 1);
        break;
      case 'clear-item':
        sendEvent(EVENT_TYPES.REMOVED, id, Cart.getQuantity(state.cart, id));
        break;
      case 'clear-trolley':
        if (window.confirm('Remove every item from the trolley?')) {
          state.cart.items.slice().forEach((item) => sendEvent(EVENT_TYPES.REMOVED, item.productId, item.quantity));
        }
        break;
      case 'category':
        state.category = target.dataset.category;
        render();
        break;
      case 'replay-last': {
        const last = state.sensor.log[0];
        if (last) {
          applyEvent({ eventId: last.eventId, productId: last.productId, eventType: last.eventType, quantity: last.quantity, timestamp: new Date().toISOString() });
        }
        break;
      }
      case 'clear-log':
        state.sensor = { ...state.sensor, log: [] };
        storage.saveSensorState(state.sensor);
        render();
        break;
      case 'confirm-checkout':
        confirmCheckout();
        break;
      case 'print-receipt':
        printReceipt(target.dataset.txn);
        break;
      case 'download-receipt':
        downloadReceipt(target.dataset.txn);
        break;
      case 'new-session':
        state.receiptId = null;
        state.lcd = lcdFromRecord(null);
        break;
      case 'clear-history':
        if (window.confirm('Delete all completed transactions? This cannot be undone.')) {
          state.transactions = [];
          storage.saveTransactions(state.transactions);
          render();
        }
        break;
      case 'reset-settings':
        state.settings = Billing.getDefaultSettings();
        storage.saveSettings(state.settings);
        renderSettingsForm();
        setSettingsMessage('Default billing settings restored.');
        render();
        break;
      case 'reset-demo':
        if (window.confirm('Reset the catalog, trolley, sensor log, settings and transaction history?')) {
          storage.clearAll();
          loadState();
          window.location.hash = 'shop';
          renderSettingsForm();
          render();
        }
        break;
      default:
        return;
    }
    if (target.tagName === 'BUTTON') event.preventDefault();
  }

  function bindEvents() {
    document.addEventListener('click', (event) => {
      const goCheckout = event.target.closest('#go-checkout');
      if (goCheckout && state.cart.items.length === 0) {
        event.preventDefault();
        return;
      }
      const target = event.target.closest('[data-action]');
      if (target && !target.disabled) handleAction(target.dataset.action, target, event);
    });

    window.addEventListener('hashchange', () => {
      render();
      el('main').focus({ preventScroll: true });
      window.scrollTo(0, 0);
    });

    const search = el('search');
    search.addEventListener('input', () => {
      state.query = search.value;
      renderCatalog();
    });
    // An exact ID or barcode followed by Enter behaves like a barcode scan.
    search.addEventListener('keydown', (event) => {
      if (event.key !== 'Enter') return;
      const code = search.value.trim();
      if (!/^(P\d+|\d{8,14})$/i.test(code)) return;
      event.preventDefault();
      search.value = '';
      state.query = '';
      sendEvent(EVENT_TYPES.ADDED, code, 1);
    });

    el('sensor-form').addEventListener('submit', (event) => {
      event.preventDefault();
      const rawQty = el('sensor-qty').value.trim();
      sendEvent(
        el('sensor-type').value,
        el('sensor-product').value.trim(),
        rawQty === '' ? NaN : Number(rawQty),
        el('sensor-event-id').value.trim() || undefined,
      );
      el('sensor-event-id').value = '';
    });

    el('discount-type').addEventListener('change', () => {
      el('discount-value').disabled = el('discount-type').value === 'none';
      if (el('discount-type').value === 'none') el('discount-value').value = '';
    });

    el('settings-form').addEventListener('submit', (event) => {
      event.preventDefault();
      const { errors, settings } = readSettingsForm();
      if (errors.length) {
        setSettingsMessage(errors.join(' '), true);
        return;
      }
      state.settings = Billing.normaliseSettings(settings);
      storage.saveSettings(state.settings);
      setSettingsMessage('Settings applied. Totals recalculated.');
      render();
    });

    // Keep other tabs consistent when they change the shared demo data.
    window.addEventListener('storage', (event) => {
      if (event.key && event.key.indexOf('smartTrolley.') === 0) {
        const { query, category, receiptId } = state;
        loadState();
        Object.assign(state, { query, category, receiptId });
        render();
      }
    });
  }

  function init() {
    loadState();
    el('storage-warning').hidden = storage.isPersistent;
    renderSettingsForm();
    bindEvents();
    render();
  }

  // Used by hardware-view.js, which drives the same state through the same sensor pipeline.
  window.SmartTrolley.App = {
    getState: () => state,
    currentView,
    escapeHtml,
    sendEvent,
    applyEvent,
    lcdMarkup,
    showAlert(lcd) {
      state.lcd = lcd;
      render();
    },
    onRender(hook) {
      renderHooks.push(hook);
    },
  };

  init();
})();
