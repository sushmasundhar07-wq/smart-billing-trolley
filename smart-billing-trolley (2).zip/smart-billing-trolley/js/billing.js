/* Billing engine: derives every total from cart lines and settings. Money is integer paise throughout. */
(function (global) {
  'use strict';

  const ns = global.SmartTrolley || (global.SmartTrolley = {});

  const DISCOUNT_TYPES = ['none', 'percent', 'flat'];

  // Demonstration rates only; real tax rules must be checked before any production use.
  const DEFAULT_SETTINGS = Object.freeze({
    defaultTaxPercent: 5,
    categoryTaxPercent: { Fruits: 0, Vegetables: 0, Snacks: 12, Household: 18 },
    discount: { type: 'none', value: 0 }, // percent: value is a percentage; flat: value is paise
  });

  function getDefaultSettings() {
    return JSON.parse(JSON.stringify(DEFAULT_SETTINGS));
  }

  function isValidPercent(value) {
    return typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= 100;
  }

  // Accepts anything (e.g. parsed storage) and returns a complete, valid settings object.
  function normaliseSettings(raw) {
    const defaults = getDefaultSettings();
    if (!raw || typeof raw !== 'object') return defaults;

    const settings = {
      defaultTaxPercent: isValidPercent(raw.defaultTaxPercent) ? raw.defaultTaxPercent : defaults.defaultTaxPercent,
      categoryTaxPercent: {},
      discount: defaults.discount,
    };

    const overrides = raw.categoryTaxPercent && typeof raw.categoryTaxPercent === 'object'
      ? raw.categoryTaxPercent
      : defaults.categoryTaxPercent;
    Object.keys(overrides).forEach((category) => {
      if (isValidPercent(overrides[category])) settings.categoryTaxPercent[category] = overrides[category];
    });

    const discount = raw.discount;
    if (discount && DISCOUNT_TYPES.includes(discount.type)) {
      if (discount.type === 'percent' && isValidPercent(discount.value)) {
        settings.discount = { type: 'percent', value: discount.value };
      } else if (discount.type === 'flat' && Number.isInteger(discount.value) && discount.value >= 0) {
        settings.discount = { type: 'flat', value: discount.value };
      } else {
        settings.discount = { type: 'none', value: 0 };
      }
    }
    return settings;
  }

  function taxPercentFor(category, settings) {
    return Object.prototype.hasOwnProperty.call(settings.categoryTaxPercent, category)
      ? settings.categoryTaxPercent[category]
      : settings.defaultTaxPercent;
  }

  // Percentages are converted to integer basis points so the only rounding step is the final Math.round.
  function percentOf(amountPaise, percent) {
    const basisPoints = Math.round(percent * 100);
    return Math.round((amountPaise * basisPoints) / 10000);
  }

  function sum(values) {
    return values.reduce((total, value) => total + value, 0);
  }

  function calculateBill(items, settings) {
    const config = normaliseSettings(settings);
    const lines = items.map((item) => {
      const lineTotalPaise = item.unitPricePaise * item.quantity;
      const taxPercent = taxPercentFor(item.category, config);
      return {
        productId: item.productId,
        name: item.name,
        category: item.category,
        unitPricePaise: item.unitPricePaise,
        quantity: item.quantity,
        lineTotalPaise,
        taxPercent,
        taxPaise: percentOf(lineTotalPaise, taxPercent),
      };
    });

    const subtotalPaise = sum(lines.map((line) => line.lineTotalPaise));
    const taxPaise = sum(lines.map((line) => line.taxPaise));

    let discountPaise = 0;
    if (config.discount.type === 'percent') discountPaise = percentOf(subtotalPaise, config.discount.value);
    if (config.discount.type === 'flat') discountPaise = config.discount.value;
    discountPaise = Math.min(discountPaise, subtotalPaise);

    return {
      lines,
      totalUnits: sum(lines.map((line) => line.quantity)),
      subtotalPaise,
      taxPaise,
      discountPaise,
      grandTotalPaise: subtotalPaise + taxPaise - discountPaise,
      discount: { ...config.discount },
    };
  }

  // Indian digit grouping: 1,23,45,678
  function groupIndian(rupees) {
    const digits = String(rupees);
    if (digits.length <= 3) return digits;
    const rest = digits.slice(0, -3).replace(/\B(?=(\d{2})+(?!\d))/g, ',');
    return `${rest},${digits.slice(-3)}`;
  }

  function formatPaise(paise) {
    const value = Number.isFinite(paise) ? Math.round(paise) : 0;
    const abs = Math.abs(value);
    const fraction = String(abs % 100).padStart(2, '0');
    return `${value < 0 ? '-' : ''}₹${groupIndian(Math.floor(abs / 100))}.${fraction}`;
  }

  // Parses user input such as "30" or "30.5" into exact paise; returns null for anything else.
  function rupeesToPaise(input) {
    const text = String(input === null || input === undefined ? '' : input).trim();
    if (!/^\d+(\.\d{1,2})?$/.test(text)) return null;
    const [whole, fraction = ''] = text.split('.');
    return Number(whole) * 100 + Number(fraction.padEnd(2, '0'));
  }

  function describeDiscount(discount) {
    if (!discount || discount.type === 'none') return 'No discount';
    if (discount.type === 'percent') return `${discount.value}% off`;
    return `${formatPaise(discount.value)} off`;
  }

  const Billing = {
    getDefaultSettings,
    normaliseSettings,
    isValidPercent,
    taxPercentFor,
    percentOf,
    calculateBill,
    formatPaise,
    rupeesToPaise,
    describeDiscount,
  };

  ns.Billing = Billing;
  if (typeof module === 'object' && module.exports) module.exports = Billing;
})(typeof globalThis !== 'undefined' ? globalThis : this);
