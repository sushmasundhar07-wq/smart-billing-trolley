/* Product catalog: sample data and lookup helpers. All prices are integer paise (₹1 = 100 paise). */
(function (global) {
  'use strict';

  const ns = global.SmartTrolley || (global.SmartTrolley = {});

  const ALL_CATEGORIES = 'All';

  // Barcodes use the 200-prefix range, which is reserved for in-store (non-retail) codes.
  const SAMPLE_PRODUCTS = Object.freeze([
    { id: 'P001', barcode: '2000000000001', name: 'Milk', category: 'Dairy', unit: 'packet', pricePaise: 3000, stock: 40, icon: '🥛' },
    { id: 'P002', barcode: '2000000000002', name: 'Bread', category: 'Bakery', unit: 'loaf', pricePaise: 4000, stock: 25, icon: '🍞' },
    { id: 'P003', barcode: '2000000000003', name: 'Basmati Rice', category: 'Grains', unit: '1 kg bag', pricePaise: 12000, stock: 30, icon: '🍚' },
    { id: 'P004', barcode: '2000000000004', name: 'Bananas', category: 'Fruits', unit: 'dozen', pricePaise: 6000, stock: 20, icon: '🍌' },
    { id: 'P005', barcode: '2000000000005', name: 'Apples', category: 'Fruits', unit: '1 kg', pricePaise: 18000, stock: 15, icon: '🍎' },
    { id: 'P006', barcode: '2000000000006', name: 'Eggs', category: 'Dairy', unit: 'tray of 12', pricePaise: 8400, stock: 18, icon: '🥚' },
    { id: 'P007', barcode: '2000000000007', name: 'Butter', category: 'Dairy', unit: '100 g', pricePaise: 5800, stock: 22, icon: '🧈' },
    { id: 'P008', barcode: '2000000000008', name: 'Tomatoes', category: 'Vegetables', unit: '1 kg', pricePaise: 4000, stock: 30, icon: '🍅' },
    { id: 'P009', barcode: '2000000000009', name: 'Potatoes', category: 'Vegetables', unit: '1 kg', pricePaise: 3500, stock: 35, icon: '🥔' },
    { id: 'P010', barcode: '2000000000010', name: 'Onions', category: 'Vegetables', unit: '1 kg', pricePaise: 4500, stock: 35, icon: '🧅' },
    { id: 'P011', barcode: '2000000000011', name: 'Orange Juice', category: 'Beverages', unit: '1 L', pricePaise: 11000, stock: 12, icon: '🧃' },
    { id: 'P012', barcode: '2000000000012', name: 'Tea Powder', category: 'Beverages', unit: '250 g', pricePaise: 14500, stock: 16, icon: '🍵' },
    { id: 'P013', barcode: '2000000000013', name: 'Biscuits', category: 'Snacks', unit: 'pack', pricePaise: 2500, stock: 50, icon: '🍪' },
    { id: 'P014', barcode: '2000000000014', name: 'Potato Chips', category: 'Snacks', unit: 'pack', pricePaise: 2000, stock: 4, icon: '🍟' },
    { id: 'P015', barcode: '2000000000015', name: 'Sugar', category: 'Grains', unit: '1 kg', pricePaise: 4800, stock: 28, icon: '🍬' },
    { id: 'P016', barcode: '2000000000016', name: 'Dish Soap', category: 'Household', unit: '500 ml', pricePaise: 9900, stock: 10, icon: '🧴' },
    { id: 'P017', barcode: '2000000000017', name: 'Cheese Slices', category: 'Dairy', unit: '10 slices', pricePaise: 14000, stock: 0, icon: '🧀' },
  ]);

  function getSampleProducts() {
    return SAMPLE_PRODUCTS.map((product) => ({ ...product }));
  }

  function isValidProduct(product) {
    return !!product &&
      typeof product.id === 'string' && product.id !== '' &&
      typeof product.barcode === 'string' &&
      typeof product.name === 'string' && product.name !== '' &&
      typeof product.category === 'string' &&
      Number.isInteger(product.pricePaise) && product.pricePaise >= 0 &&
      Number.isInteger(product.stock) && product.stock >= 0;
  }

  function isValidCatalog(products) {
    return Array.isArray(products) && products.length > 0 && products.every(isValidProduct);
  }

  // Looks a product up by exact product ID (case-insensitive) or barcode.
  function findProduct(products, code) {
    if (code === null || code === undefined) return null;
    const key = String(code).trim().toUpperCase();
    if (!key) return null;
    return products.find((product) => product.id.toUpperCase() === key || product.barcode === key) || null;
  }

  function searchProducts(products, query, category) {
    const text = String(query || '').trim().toLowerCase();
    return products.filter((product) => {
      if (category && category !== ALL_CATEGORIES && product.category !== category) return false;
      if (!text) return true;
      return product.name.toLowerCase().includes(text) ||
        product.id.toLowerCase().includes(text) ||
        product.barcode.includes(text);
    });
  }

  function getCategories(products) {
    return Array.from(new Set(products.map((product) => product.category))).sort();
  }

  const Products = {
    ALL_CATEGORIES,
    getSampleProducts,
    isValidProduct,
    isValidCatalog,
    findProduct,
    searchProducts,
    getCategories,
  };

  ns.Products = Products;
  if (typeof module === 'object' && module.exports) module.exports = Products;
})(typeof globalThis !== 'undefined' ? globalThis : this);
